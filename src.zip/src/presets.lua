return {
["Heavy"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Chaotic";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer"; Settings = {
            Mode     = "forward";
            MaxDepth = 5;
        } };
        { Name = "EncryptStrings";  Settings = {} };
        { Name = "SplitStrings";    Settings = {} };
        { Name = "DynamicXOR";      Settings = { Treshold = 0.45 } };
        { Name = "DynamicDecrypt";  Settings = { Threshold = 0.70; Rounds = 3 } };        
        { Name = "DynamicJumps"; Settings = {
            Threshold     = 0.75;
            PoolSize      = 64;
            MinStatements = 2;
        } };
        { Name = "ConstantsObfuscator"; Settings = {
            ObfuscateNumbers  = true;
            ObfuscateStrings  = true;
            MockStringChance  = 2;
            MinAbsValue       = 1;
        } };
        { Name = "ConstantArray"; Settings = {
            Treshold              = 1;
            StringsOnly           = true;
            Shuffle               = true;
            Rotate                = true;
            LocalWrapperTreshold  = 1;
            LocalWrapperCount     = 3;
            LocalWrapperArgCount  = 12;
        } };
        { Name = "NumbersToExpressions"; Settings = {
            Treshold         = 0.80;
            InternalTreshold = 0.25;
        } };
        { Name = "OpaquePredicates"; Settings = {
            Treshold           = 0.85;
            InjectionsPerBlock = 2;
        } };
        { Name = "StatementFlattener"; Settings = {
            FlattenIf        = true;
            FlattenFunctions = true;
            Threshold        = 0.65;
        } };
        { Name = "JunkStatements"; Settings = {
            InjectionCount  = 2;
            Treshold        = 0.75;
            TableWriteRatio = 0.5;
            ChainLength     = 3;
            TableWriteCount = 3;
        } };
        { Name = "Vmify"; Settings = { OptimizationLevel = 2 } };
        { Name = "FakeLoopWrap";   Settings = { Treshold = 0.35 } };
        { Name = "VirtualGlobals"; Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction"; Settings = {} };
        { Name = "Compressor";    Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["Fast"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "ByteAddr";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 4 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.6; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.3; LocalWrapperCount = 1; LocalWrapperArgCount = 4;
        } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.2 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
		{ Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["Light"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 12; MaxInterval = 22; GlobalScanCount = 7 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 4 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.8; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.5; InternalTreshold = 0.15 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 0.6; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
    };
    Hercules = nil;
};
["Strings"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = true;
    Seed          = 0;
    Steps = {
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "LocalsToTable";        Settings = { TableKeyStyle = "string" } };
    };
    Hercules = nil;
};
["TableOnly"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 4 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "LocalsToTable";        Settings = { TableKeyStyle = "string" } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.8; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.6; InternalTreshold = 0.15 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.55; InjectionsPerBlock = 1 } };
		 { Name = "VmifyLegacy";          Settings = {} };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 0.8; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
    };
    Hercules = nil;
};
["Legacy"] = {
    NameGenerator = "Vnlight",
    LuaVersion    = "Lua51",
    PrettyPrint   = false,
    Steps = {
        { Name = "VmifyLegacy";          Settings = {} };
    },
},
["Test"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "AN";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "Vmify";   Settings = { OptimizationLevel = 1 } };
    };
    Hercules = nil;
};
["Byte"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Chaotic";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "SplitStrings";         Settings = {} };
		{ Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.65; InjectionsPerBlock = 2 } };
        { Name = "ConstantsObfuscator";  Settings = { ObfuscateNumbers = true; ObfuscateStrings = true; MockStringChance = 8; MinAbsValue = 4; } };
		{ Name = "VmifyBC"; Settings = {} };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};
["Default"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "ANLight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        --{ Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 25; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
		{ Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.65; InjectionsPerBlock = 2 } };
		{ Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
		{ Name = "AntiTamper";             Settings = {} };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.30 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["Medium"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["HttpGet"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.40 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
        { Name = "ConstantArray";        Settings = { Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true; LocalWrapperTreshold = 0.7; LocalWrapperCount = 2; LocalWrapperArgCount = 8; } };
        { Name = "ConstantsObfuscator";  Settings = { ObfuscateNumbers = true; ObfuscateStrings = true; MockStringChance = 1; MinAbsValue = 1; } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.5; InternalTreshold = 0.2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.75; InjectionsPerBlock = 2 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.60 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["Luraph"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Chaotic";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
       { Name = "InvertedExecution";    Settings = { ChunkSize = 8; RandomiseIds = true; JunkChunks = 6 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";       Settings = {} };
        --{ Name = "AntiTamper";           Settings = { UseDebug = false } };
		{ Name = "DynamicXOR";           Settings = { Treshold = 0.40 } };       			
		{ Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };       
		{ Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 1; MinAbsValue = 1;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.2; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };		
		{ Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.60 } };
        --{ Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
      --  { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
		{ Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
    };
    Hercules = nil;
	};
["Luarmor"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "ByteAddr";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.40 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 1; MinAbsValue = 1;
        } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.7; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.5; InternalTreshold = 0.2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.75; InjectionsPerBlock = 2 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.60 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.30 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = {
            EliminateJunkLocals = true; FoldIdentities = true;
            EliminateDeadIf = true; EliminateEmptyDo = true;
        } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["77"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.45 } };
        { Name = "LocalsToTable";        Settings = { TableKeyStyle = "string" } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.9; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.60; InjectionsPerBlock = 2 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "VmifyLegacy";          Settings = {} };
        { Name = "ArgsAsOpcodes";        Settings = { ShuffleArgs = true; PassVararg = true } };
        { Name = "BootstrapObfuscator";  Settings = { StatementsPerState = 1; AddJunkState = true } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
    };
    Hercules = nil;
};
["Stack"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "DynPrefix";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.45 } };
        { Name = "LocalsToTable";        Settings = { TableKeyStyle = "string" } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.60; InjectionsPerBlock = 2 } };
			 { Name = "VmifyLegacy";          Settings = {} };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
    };
    Hercules = nil;
};
["StackMedium"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vn";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.45 } };
        { Name = "LocalsToTable";        Settings = { TableKeyStyle = "string" } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.9; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.7; InternalTreshold = 0.2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.65; InjectionsPerBlock = 2 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.30 } };
        { Name = "VmifyLegacy";          Settings = {} };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["StackHeavy"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Dynamic";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "IntegrityHash";        Settings = { SampleSize = 16; UseFakeExec = true } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
        { Name = "LocalsToTable";        Settings = { TableKeyStyle = "string" } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 1; MinAbsValue = 1;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 3 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.65 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "VmifyLegacy";          Settings = {} };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
}