-- ZukaTech/legacy/ir.lua
-- Prometheus legacy IR (Intermediate Representation) library, re-pathed for ZukaTech.
-- Original: Prometheus Obfuscator by Levno_710

local logger = require("logger");
local util   = require("ZukaTech.util");

local Bytecode        = require("ZukaTech.legacy.bytecode");
local InstructionKind = Bytecode.InstructionKind;

local function Instruction(tb)
    tb.pos = -1;
    tb.toString = tb.toString or function(self)
        local ret = self.kind;
        if self.a then
            if self.b then
                ret = string.format("%s %d, %d", self.kind, self.a, self.b)
            else
                ret = string.format("%s %d", self.kind, self.a)
            end
        end
        return ret .. (self.comment and (" ;" .. self.comment) or "");
    end
    return tb;
end

local IR = {
    InstructionKind = InstructionKind,
};

function IR:new()
    local ir = {
        functions        = {},
        instructions     = {},
        constants        = {},
        constantsLookup  = {},
        instructionUsed  = {},
    }
    setmetatable(ir, self);
    self.__index = self;
    return ir;
end

function IR:pushInstruction(instruction, pos)
    self.instructionUsed[instruction.kind] = true;
    if pos then
        table.insert(self.instructions, pos, instruction);
    else
        table.insert(self.instructions, instruction);
    end
    return #self.instructions
end
IR.instruction = IR.pushInstruction;

function IR:createFunction(ins)
    local id = #self.functions + 1;
    table.insert(self.functions, ins);
    return id;
end

function IR:instructionIsUsed(kind)
    return self.instructionUsed[kind] == true;
end

function IR:getCurrentPos()
    return #self.instructions
end

function IR:toString()
    self:updateInstructionPosInfo();
    local str = ".func\n";

    for i, funcInstruction in ipairs(self.functions) do
        str = str .. string.format("%4d:  %d\n", i, funcInstruction.pos);
    end

    str = str .. ".code\n";

    for i, ins in ipairs(self.instructions) do
        str = str .. string.format("%4d:  %s\n", ins.pos, ins:toString());
    end

    str = str .. ".const\n";

    for id, const in ipairs(self.constants) do
        if type(const) == "string" then
            str = str .. string.format("%4d:  \"%s\"\n", id, util.escape(const));
        else
            str = str .. string.format("%4d:  %d\n", id, const);
        end
    end

    return str;
end

function IR:updateInstructionPosInfo()
    for i, ins in ipairs(self.instructions) do
        ins.pos = i;
    end
    for i, ins in ipairs(self.instructions) do
        if ins.kind == InstructionKind.JMP or ins.kind == InstructionKind.JMPC then
            if not ins.to then
                error("[VmifyLegacy] JMP/JMPC at pos " .. tostring(i)
                    .. " has a nil jump target. This is a compiler bug.")
            end
            if not ins.to.pos then
                error("[VmifyLegacy] JMP/JMPC at pos " .. tostring(i)
                    .. " targets an instruction that was never emitted (no pos). "
                    .. "Ensure every IR:NOP() used as a jump label is passed to ir:instruction().")
            end
            ins.a = ins.to.pos;
        end
    end
end

function IR:constant(value)
    -- Coerce booleans to their string equivalents so they can be stored
    -- in the constant pool. The VM handles actual boolean logic via
    -- LOADTRUE/LOADFALSE; this only affects cases where a boolean leaks
    -- into a constant slot (e.g. after LocalsToTable transforms).
    if type(value) == "boolean" then
        value = tostring(value) -- "true" or "false"
    end
    -- nil means a variable was removed from scope.variables[] by a prior
    -- pipeline step (e.g. LocalsToTable) before the compiler read its name.
    -- Substitute a safe synthetic global name so the bytecode stays valid.
    if value == nil then
        value = "__zk_nil_" .. tostring(#self.constants + 1)
    end
    if type(value) == "string" or type(value) == "number" then
        if self.constantsLookup[value] then
            return self.constantsLookup[value]
        end
        table.insert(self.constants, value)
        local id = #self.constants;
        self.constantsLookup[value] = id;
        return id;
    else
        logger:error(
            "IR Constants must be Strings or Numbers. Got: "
            .. type(value) .. " (" .. tostring(value) .. ")")
    end
end

function IR:optimize()
    self:stripNopsAndAddJumpInfo();
    self:stripDeadInstructions();
    self:updateUsedInstructions();
end

function IR:updateUsedInstructions()
    self.instructionUsed = {};
    for i, instruction in ipairs(self.instructions) do
        self.instructionUsed[instruction.kind] = true;
    end
end

function IR:stripDeadInstructions()
    local insc   = {};
    local isDead = false;
    local skip   = false;
    for i, instruction in ipairs(self.instructions) do
        if instruction.isJumpedTo then
            isDead = false;
        end

        if not isDead then
            insc[#insc + 1] = instruction;
        end

        if skip then
            skip = false
        else
            if instruction.kind == InstructionKind.FORSKIP
            or instruction.kind == InstructionKind.FORINSKIP then
                skip = true;
            elseif instruction.kind == InstructionKind.JMP
                or instruction.kind == InstructionKind.RET
                or instruction.kind == InstructionKind.RET2
                or instruction.kind == InstructionKind.RET3 then
                isDead = true;
            end
        end
    end
    self.instructions = insc;
end

function IR:setJumpmarksToNextInstruction()
    self:updateInstructionPosInfo();
    for i, ins in ipairs(self.functions) do
        ins.isJumpedTo = true;
    end
    for i, instruction in ipairs(self.instructions) do
        if instruction.kind == InstructionKind.JMP
        or instruction.kind == InstructionKind.JMPC then
            local to = instruction.to;
            while to and to.kind == InstructionKind.NOP do
                local next = self.instructions[to.pos + 1];
                if not next then break end  -- NOP is last instruction; stop here
                to = next;
            end
            if not to then
                error("[VmifyLegacy] JMP/JMPC target resolved to nil during NOP strip. "
                    .. "Instruction at pos " .. tostring(instruction.pos)
                    .. " has a dangling jump target.")
            end
            instruction.to = to;
            to.isJumpedTo = true;
            to.jumpedToFrom = to.jumpedToFrom or {};
            table.insert(to.jumpedToFrom, instruction);
        end
    end
end

function IR:stripNopsAndAddJumpInfo()
    self:setJumpmarksToNextInstruction();
    local insc = {};
    for i, instruction in ipairs(self.instructions) do
        if instruction.kind ~= InstructionKind.NOP or instruction.isJumpedTo then
            insc[#insc + 1] = instruction;
        end
    end
    self.instructions = insc;
end

-- ── Instruction constructors ──────────────────────────────────────────────────

function IR:UNPACK()        return Instruction{ kind = InstructionKind.UNPACK }       end
function IR:PACK()          return Instruction{ kind = InstructionKind.PACK }         end
function IR:UNPACKFIRST()   return Instruction{ kind = InstructionKind.UNPACKFIRST }  end
function IR:PUSHSCOPE()     return Instruction{ kind = InstructionKind.PUSHSCOPE }    end
function IR:POPSCOPE()      return Instruction{ kind = InstructionKind.POPSCOPE }     end
function IR:EQ()            return Instruction{ kind = InstructionKind.EQ }           end
function IR:NEQ()           return Instruction{ kind = InstructionKind.NEQ }          end
function IR:LT()            return Instruction{ kind = InstructionKind.LT }           end
function IR:LET()           return Instruction{ kind = InstructionKind.LET }          end
function IR:DUP()           return Instruction{ kind = InstructionKind.DUP }          end
function IR:PUSHTEMPSTACK() return Instruction{ kind = InstructionKind.PUSHTEMPSTACK }end
function IR:PUSHTEMPSTACK2()return Instruction{ kind = InstructionKind.PUSHTEMPSTACK2}end
function IR:POPTEMPSTACK()  return Instruction{ kind = InstructionKind.POPTEMPSTACK } end
function IR:POPTEMPSTACK2() return Instruction{ kind = InstructionKind.POPTEMPSTACK2 }end
function IR:GT()            return Instruction{ kind = InstructionKind.GT }           end
function IR:GET()           return Instruction{ kind = InstructionKind.GET }          end
function IR:NOT()           return Instruction{ kind = InstructionKind.NOT }          end
function IR:FORPREP()       return Instruction{ kind = InstructionKind.FORPREP }      end
function IR:GETGLOBAL()     return Instruction{ kind = InstructionKind.GETGLOBAL }    end
function IR:SETGLOBAL()     return Instruction{ kind = InstructionKind.SETGLOBAL }    end
function IR:POPTABLESTART() return Instruction{ kind = InstructionKind.POPTABLESTART }end
function IR:NEWTABLE()      return Instruction{ kind = InstructionKind.NEWTABLE }     end
function IR:GETTABLE()      return Instruction{ kind = InstructionKind.GETTABLE }     end
function IR:GETTABLE2()     return Instruction{ kind = InstructionKind.GETTABLE2 }    end
function IR:SETTABLE()      return Instruction{ kind = InstructionKind.SETTABLE }     end
function IR:SETARGS()       return Instruction{ kind = InstructionKind.SETARGS }      end
function IR:CLEARSTACK()    return Instruction{ kind = InstructionKind.CLEARSTACK }   end
function IR:RET()           return Instruction{ kind = InstructionKind.RET }          end
function IR:RET2()          return Instruction{ kind = InstructionKind.RET2 }         end
function IR:RET3()          return Instruction{ kind = InstructionKind.RET3 }         end
function IR:DROP()          return Instruction{ kind = InstructionKind.DROP }         end
function IR:CALL()          return Instruction{ kind = InstructionKind.CALL }         end
function IR:NOP()           return Instruction{ kind = InstructionKind.NOP }          end
function IR:LOADNIL()       return Instruction{ kind = InstructionKind.LOADNIL }      end
function IR:LOADTRUE()      return Instruction{ kind = InstructionKind.LOADTRUE }     end
function IR:LOADFALSE()     return Instruction{ kind = InstructionKind.LOADFALSE }    end
function IR:FORINSKIP()     return Instruction{ kind = InstructionKind.FORINSKIP }    end
function IR:NEG()           return Instruction{ kind = InstructionKind.NEG }          end
function IR:CONCAT()        return Instruction{ kind = InstructionKind.CONCAT }       end
function IR:ADD()           return Instruction{ kind = InstructionKind.ADD }          end
function IR:SUB()           return Instruction{ kind = InstructionKind.SUB }          end
function IR:MUL()           return Instruction{ kind = InstructionKind.MUL }          end
function IR:DIV()           return Instruction{ kind = InstructionKind.DIV }          end
function IR:MOD()           return Instruction{ kind = InstructionKind.MOD }          end
function IR:POW()           return Instruction{ kind = InstructionKind.POW }          end
function IR:LEN()           return Instruction{ kind = InstructionKind.LEN }          end
function IR:CRASH()         return Instruction{ kind = InstructionKind.CRASH }        end

function IR:SWAP(offset)
    return Instruction{ kind = InstructionKind.SWAP, a = offset or 1 }
end

function IR:LOADCONST(id)
    return Instruction{ kind = InstructionKind.LOADCONST, a = id }
end

function IR:FORSKIP(varid)
    return Instruction{ kind = InstructionKind.FORSKIP, a = varid }
end

function IR:ASSIGNGLOBAL(n)
    return Instruction{ kind = InstructionKind.ASSIGNGLOBAL, a = n }
end

function IR:GETLOCAL(id, scopeShift)
    return Instruction{ kind = InstructionKind.GETLOCAL, a = id, b = scopeShift }
end

function IR:SETLOCAL(id, scopeShift)
    return Instruction{ kind = InstructionKind.SETLOCAL, a = id, b = scopeShift }
end

function IR:ASSIGNLOCAL(id, scopeShift)
    return Instruction{ kind = InstructionKind.ASSIGNLOCAL, a = id, b = scopeShift }
end

function IR:JMP(to)
    return Instruction{ kind = InstructionKind.JMP, to = to }
end

function IR:JMPC(to)
    return Instruction{ kind = InstructionKind.JMPC, to = to }
end

function IR:SETTABLE2(idx)
    return Instruction{ kind = InstructionKind.SETTABLE2, a = idx }
end

function IR:SETTABLE3(idx)
    return Instruction{ kind = InstructionKind.SETTABLE3, a = idx }
end

function IR:ASSIGNTABLE(i, offset)
    return Instruction{ kind = InstructionKind.ASSIGNTABLE, a = i, b = offset }
end

function IR:LOADARGS(start)
    return Instruction{ kind = InstructionKind.LOADARGS, a = start or 0 }
end

function IR:LOADARG(n)
    return Instruction{ kind = InstructionKind.LOADARG, a = n }
end

function IR:FUNC(id)
    return Instruction{ kind = InstructionKind.FUNC, a = id }
end

return IR;