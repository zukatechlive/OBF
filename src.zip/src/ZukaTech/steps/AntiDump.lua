-- Obfuscation Step: Anti-Dump (v2)
--
-- FIX SUMMARY vs v1:
--   * REMOVED __namecall trap. In Luau, __namecall only fires when the
--     NAMECALL opcode is emitted by the compiler for known method names.
--     Calling :_check() on a dynamically created table does NOT reliably
--     trigger __namecall in all executor VMs — it fell through to __index,
--     returned a function, got called, returned nil (not sentinelVal), and
--     set _trap_ok = false on EVERY run regardless of hooks. This was the
--     primary cause of silent corruption crashes.
--   * Upvalue bait check kept — it's valid and works correctly.
--   * GC pressure kept — collectgarbage("count") is Luau-safe.
--   * Added a getrawmetatable probe: executors that hook getrawmetatable
--     replace it with a Lua wrapper; we detect that via debug.getinfo.

local Step   = require("ZukaTech.step")
local Ast    = require("ZukaTech.ast")
local Parser = require("ZukaTech.parser")
local Enums  = require("ZukaTech.enums")

local LuaVersion = Enums.LuaVersion

local AntiDump       = Step:extend()
AntiDump.Description = "Upvalue bait + GC pressure to resist memory dumpers. __namecall trap removed (false-positived in Luau)."
AntiDump.Name        = "Anti Dump"

AntiDump.SettingsDescriptor = {
    GCInterval = {
        name        = "GCInterval",
        description = "Number of allocation loops in the GC pressure section",
        type        = "number",
        default     = 50,
        min         = 10,
        max         = 500,
    },
}

function AntiDump:init(settings) end

function AntiDump:apply(ast, pipeline)
    local gcInterval = self.GCInterval or 50

    local sentinelVal = math.random(100000, 999999)
    local sentinelKey = "_zt" .. math.random(10000, 99999)

    -- NOTE: __namecall trap removed. It did NOT work in Luau because the
    -- NAMECALL opcode is only emitted for compile-time-known method names.
    -- Dynamically calling :_check() on a fresh table falls back to __index
    -- then calls the returned function — __namecall is never invoked.
    -- The result was always nil, making _trap_ok always false, silently
    -- corrupting every obfuscated script regardless of executor hooks.

    local code = string.format([[
do
    local _trap_ok = true

    -- B) Upvalue scanner bait
    -- A local table is created with a sentinel value.
    -- If an executor replaces _bait between declaration and the read-back
    -- below, the sentinel will differ.
    local _bait = { ["%s"] = %d }
    local function _bait_reader()
        return _bait["%s"]
    end
    if _bait_reader() ~= %d then
        _trap_ok = false
    end

    -- C) getrawmetatable hook probe via debug.getinfo
    -- getrawmetatable is a C function in unmodified Luau.
    -- If an executor replaced it with a Lua wrapper, what ~= "C".
    do
        local _dbg = debug
        if _dbg and _dbg["getinfo"] then
            local _grm = getrawmetatable
            if _grm ~= nil then
                local _gi = _dbg["getinfo"](_grm)
                if _gi and _gi["what"] ~= "C" then
                    _trap_ok = false
                end
            end
        end
    end

    -- D) GC count read — adds timing entropy, Luau-safe
    local _gc1 = collectgarbage("count")
    for _i = 1, %d do
        local _t = {}
        for _j = 1, 8 do _t[_j] = _i * _j end
        _t = nil
    end
    local _gc2 = collectgarbage("count")

    if not _trap_ok then
        task.defer(function() while true do task.wait(1e9) end end)
        while true do task.wait(1e9) end
    end
end
]],
        sentinelKey, sentinelVal,
        sentinelKey, sentinelVal,
        gcInterval
    )

    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(code) end)
    if not ok then return ast end

    for i = #parsed.body.statements, 1, -1 do
        local stat = parsed.body.statements[i]
        if stat.body and stat.body.scope then
            stat.body.scope:setParent(ast.body.scope)
        end
        table.insert(ast.body.statements, 1, stat)
    end

    return ast
end

return AntiDump
