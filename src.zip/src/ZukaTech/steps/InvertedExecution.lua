local Step = require("ZukaTech.step")
local Ast = require("ZukaTech.ast")
local Scope = require("ZukaTech.scope")
local AstKind = Ast.AstKind

local InvertedExecution = Step:extend()
InvertedExecution.Name = "Inverted Execution"
InvertedExecution.Description = "Physically flips the script so the last chunk appears first in the file; logical execution order is preserved via a bottom-anchored state machine dispatcher."

InvertedExecution.SettingsDescriptor = {
    ChunkSize = {
        type = "number",
        default = 1,
        min = 1,
        max = 20,
    },
    RandomiseIds = {
        type = "boolean",
        default = true,
    },
    JunkChunks = {
        type = "number",
        default = 3,
        min = 0,
        max = 20,
    },
}

function InvertedExecution:init(settings) end

local usedIds = {}
local function freshId(randomise)
    local id
    repeat
        if randomise then
            id = math.random(100000, 999999)
        else
            id = math.random(10000, 99999)
        end
    until not usedIds[id]
    usedIds[id] = true
    return id
end

local function resetIds()
    usedIds = {}
end

-- Each handler is:  function(...) do  <stmts>  local _ret = nextId  return _ret  end  end
-- The inner do..end guarantees the last char of bodyCode is 'd' (an ident char)
-- so whitespaceIfNeeded2 always inserts a space before the outer "end".
-- Every Ast.Block gets its own dedicated Scope:new(parent) — never reuse a
-- parent scope as a block scope or the unparser corrupts variable name resolution.
local function makeHandlerFunc(innerStmts, nextId, parentScope)
    local funcScope = Scope:new(parentScope)
    local doScope   = Scope:new(funcScope)
    local retId     = doScope:addVariable()

    local doBody = {}
    for _, s in ipairs(innerStmts) do
        table.insert(doBody, s)
    end
    table.insert(doBody,
        Ast.LocalVariableDeclaration(
            doScope,
            { retId },
            { Ast.NumberExpression(nextId) }
        )
    )
    table.insert(doBody,
        Ast.ReturnStatement({ Ast.VariableExpression(doScope, retId) })
    )

    local funcBody = Ast.Block({
        Ast.DoStatement(Ast.Block(doBody, doScope))
    }, funcScope)

    return Ast.FunctionLiteralExpression({ Ast.VarargExpression() }, funcBody)
end

function InvertedExecution:apply(ast)
    local statements = ast.body.statements
    if not statements or #statements == 0 then return end

    resetIds()

    local chunkSize = self.ChunkSize
    local randomise = self.RandomiseIds
    local junkCount = self.JunkChunks
    local terminate = 0
    local rootScope = ast.body.scope

    -- HOISTING PASS -----------------------------------------------------------
    -- Every local declared at the top level lives inside a chunk handler
    -- function closure after transformation. Because each handler is a separate
    -- function, locals declared in one handler are invisible to all others.
    -- Fix: collect every LocalVariableDeclaration and LocalFunctionDeclaration
    -- id from the original statement list, emit them as shared upvalue locals
    -- (initialised to nil) BEFORE the dispatch table, then rewrite each
    -- original declaration inside its chunk into a plain assignment so the
    -- value is written into the shared upvalue rather than a dead function-local.
    --------------------------------------------------------------------------

    local hoistedIds   = {}  -- scope variable id -> true (dedup)
    local hoistedOrder = {}  -- ordered list of ids for the nil-init declaration

    for _, stmt in ipairs(statements) do
        if stmt.kind == AstKind.LocalVariableDeclaration then
            for _, id in ipairs(stmt.ids) do
                if not hoistedIds[id] then
                    hoistedIds[id] = true
                    table.insert(hoistedOrder, id)
                end
            end
        elseif stmt.kind == AstKind.LocalFunctionDeclaration then
            local id = stmt.id
            if not hoistedIds[id] then
                hoistedIds[id] = true
                table.insert(hoistedOrder, id)
            end
        end
    end

    -- Rewrite declarations inside a chunk's statement list into plain
    -- assignments so they write into the shared upvalue instead of creating
    -- new dead function-locals.
    --
    --   local x, y = expr1, expr2        ->  x, y = expr1, expr2
    --   local function f(args) body end  ->  f = function(args) body end
    --
    -- Statements of other kinds are left untouched.
    local function rewriteLocals(stmtList)
        local out = {}
        for _, stmt in ipairs(stmtList) do
            if stmt.kind == AstKind.LocalVariableDeclaration and #stmt.ids > 0 then
                local lhs = {}
                for _, id in ipairs(stmt.ids) do
                    table.insert(lhs, Ast.AssignmentVariable(rootScope, id))
                end
                -- expressions may be shorter than ids (e.g. "local a, b = f()")
                -- that is fine — AssignmentStatement handles it identically.
                -- rhs can be empty for bare "local x" with no initialiser,
                -- we leave it as {} which the unparser skips correctly.
                local rhs = stmt.expressions or {}
                table.insert(out, Ast.AssignmentStatement(lhs, rhs))
            elseif stmt.kind == AstKind.LocalFunctionDeclaration then
                -- local function f(args) body end
                -- ->  f = function(args) body end
                local lhs = { Ast.AssignmentVariable(rootScope, stmt.id) }
                local rhs = { Ast.FunctionLiteralExpression(stmt.args, stmt.body) }
                table.insert(out, Ast.AssignmentStatement(lhs, rhs))
            else
                table.insert(out, stmt)
            end
        end
        return out
    end

    -- Split statements into chunks and rewrite locals in each chunk.
    local chunks = {}
    local cur = {}
    for i, stmt in ipairs(statements) do
        table.insert(cur, stmt)
        if #cur >= chunkSize or i == #statements then
            table.insert(chunks, rewriteLocals(cur))
            cur = {}
        end
    end

    local n = #chunks
    local realIds = {}
    for i = 1, n do
        realIds[i] = freshId(randomise)
    end

    local tableEntries = {}
    local function addJunkEntry()
        local jId  = freshId(randomise)
        local func = makeHandlerFunc({}, terminate, rootScope)
        table.insert(tableEntries,
            Ast.KeyedTableEntry(Ast.NumberExpression(jId), func))
    end

    local junkBudget = junkCount
    local function maybeJunk()
        if junkBudget > 0 and math.random() < 0.55 then
            addJunkEntry()
            junkBudget = junkBudget - 1
        end
    end

    for i = n, 1, -1 do
        maybeJunk()
        local nextId = realIds[i + 1] or terminate
        local func   = makeHandlerFunc(chunks[i], nextId, rootScope)
        table.insert(tableEntries,
            Ast.KeyedTableEntry(Ast.NumberExpression(realIds[i]), func))
    end

    while junkBudget > 0 do
        addJunkEntry()
        junkBudget = junkBudget - 1
    end

    local function rvar(prefix)
        local s = ""
        local charset = "abcdefghijklmnopqrstuvwxyz"
        for _ = 1, 7 do
            local idx = math.random(1, #charset)
            s = s .. charset:sub(idx, idx)
        end
        return prefix .. s
    end

    local dispId  = rootScope:addVariable(rvar("_D"))
    local stateId = rootScope:addVariable(rvar("_S"))

    local newStmts = {}

    -- Emit hoisted upvalue nil-initialisers before the dispatch table.
    -- Batched into groups of 8 to stay within Lua's multi-assign limits
    -- and keep emitted line lengths reasonable.
    local BATCH = 8
    local hi = 1
    while hi <= #hoistedOrder do
        local batchIds  = {}
        local batchNils = {}
        for b = hi, math.min(hi + BATCH - 1, #hoistedOrder) do
            table.insert(batchIds,  hoistedOrder[b])
            table.insert(batchNils, Ast.NilExpression())
        end
        table.insert(newStmts,
            Ast.LocalVariableDeclaration(rootScope, batchIds, batchNils))
        hi = hi + BATCH
    end

    -- Dispatch table and initial state.
    table.insert(newStmts,
        Ast.LocalVariableDeclaration(
            rootScope,
            { dispId },
            { Ast.TableConstructorExpression(tableEntries) }
        )
    )

    table.insert(newStmts,
        Ast.LocalVariableDeclaration(
            rootScope,
            { stateId },
            { Ast.NumberExpression(realIds[1]) }
        )
    )

    local dispatchCall = Ast.FunctionCallExpression(
        Ast.IndexExpression(
            Ast.VariableExpression(rootScope, dispId),
            Ast.VariableExpression(rootScope, stateId)
        ),
        {}
    )

    -- The while body needs its own child scope — reusing rootScope as a block
    -- scope corrupts variable name resolution in the unparser.
    local loopScope = Scope:new(rootScope)
    local loopBody  = Ast.Block({
        Ast.AssignmentStatement(
            { Ast.AssignmentVariable(rootScope, stateId) },
            { dispatchCall }
        )
    }, loopScope)

    local loopCond = Ast.NotEqualsExpression(
        Ast.VariableExpression(rootScope, stateId),
        Ast.NumberExpression(terminate)
    )

    table.insert(newStmts, Ast.WhileStatement(loopBody, loopCond))

    ast.body.statements = newStmts
    return ast
end

return InvertedExecution