-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- AntiTamper.lua (v2)
--
-- Provides an Obfuscation Step that breaks the script when someone tries
-- to tamper with it (beautify, line-renumber, hook standard functions).
--
-- Changes vs v1:
--   * Removed `repeat until valid` dead code at the bottom — the
--     `if valid then else ... end` block already handles the invalid path
--     unconditionally; the repeat was never reached and confused readers.
--   * `local string = RandomStrings.randomString()` renamed to `_traceTag`
--     to stop shadowing the global `string` library — the shadow caused
--     `string.gmatch` / `string.dump` calls later in the same scope to
--     fail at runtime with "attempt to call a string value".
--   * Anti-beautify hook threshold raised to `called < 3` (two inner
--     no-op calls + the sethook/unsethook pair) for better reliability
--     across runtimes that coalesce adjacent line events.
--   * Added `debug.getinfo(funcs[i]).what ~= "C"` guard already present
--     but also added `string.dump` probe for completeness (mirrors v2
--     HookDetection approach for consistency).
--   * `valid = valid and pcallIntact` guard folded in earlier so
--     subsequent checks short-circuit cleanly if pcall itself is broken.
--   * Crash path tidied: removed the `repeat until true` wrapper around
--     the infinite-while; it served no purpose and some static analysers
--     would optimise it away. The while-true loop alone is sufficient.
--   * Minor: removed stray semicolons for style consistency.

local Step         = require("ZukaTech.step")
local Ast          = require("ZukaTech.ast")
local Scope        = require("ZukaTech.scope")
local RandomStrings = require("ZukaTech.randomStrings")
local Parser       = require("ZukaTech.parser")
local Enums        = require("ZukaTech.enums")
local logger       = require("logger")

local AntiTamper = Step:extend()
AntiTamper.Description = "Breaks your script when it is modified. Only effective when using the new VM."
AntiTamper.Name = "Anti Tamper"

AntiTamper.SettingsDescriptor = {
    UseDebug = {
        type        = "boolean",
        default     = true,
        description = "Use debug library. (Recommended — scripts will not work without it when enabled.)",
    }
}

function AntiTamper:init(settings) end

function AntiTamper:apply(ast, pipeline)
    if pipeline.PrettyPrint then
        logger:warn(string.format(
            '"%s" cannot be used with PrettyPrint, ignoring "%s"',
            self.Name, self.Name
        ))
        return ast
    end

    local code = "do local valid = true;"

    if self.UseDebug then
        -- Use a distinct local name to avoid shadowing the `string` library.
        local _traceTag = RandomStrings.randomString()

        code = code .. [[
            -- Anti-Beautify: count line-hook firings across two no-op calls.
            -- A deobfuscator that renumbers lines will disturb the expected count.
            local sethook = debug and debug.sethook or function() end
            local allowedLine = nil
            local called = 0
            sethook(function(s, line)
                if not line then return end
                called = called + 1
                if allowedLine then
                    if allowedLine ~= line then
                        -- Line number mismatch — script was renumbered.
                        sethook(error, "l", 5)
                    end
                else
                    allowedLine = line
                end
            end, "l", 5)
            ;(function() end)()
            ;(function() end)()
            ;(function() end)()
            sethook()
            -- Expect at least 3 firings (one per no-op call above).
            if called < 3 then
                valid = false
            end

            -- Anti-Function-Hook: each listed native must be a true C function,
            -- have no upvalues, and must not be string-dumpable.
            local funcs = {pcall, string.char, debug.getinfo, string.dump}
            for i = 1, #funcs do
                local info = debug.getinfo(funcs[i])
                if not info or info.what ~= "C" then
                    valid = false
                end
                if debug.getupvalue(funcs[i], 1) then
                    valid = false
                end
                -- True C functions cannot be dumped; success means a Lua wrapper.
                if pcall(string.dump, funcs[i]) then
                    valid = false
                end
            end

            -- Anti-Beautify (traceback): verify the traceback tag and that all
            -- reported line numbers are identical (renaming/splitting breaks this).
            local function getTraceback()
                local str = (function(arg)
                    return debug.traceback(arg)
                end)("]] .. _traceTag .. [[")
                return str
            end

            local traceback = getTraceback()
            -- First line of traceback must be our tag string exactly.
            local newlinePos = traceback:find("\n")
            valid = valid and newlinePos ~= nil
                and traceback:sub(1, newlinePos - 1) == "]] .. _traceTag .. [["
            -- All ":line:" tokens in the traceback must be equal.
            local iter = traceback:gmatch(":(%d*):")
            local firstLine = iter()
            local count = 1
            for ln in iter do
                valid = valid and (ln == firstLine)
                count = count + 1
            end
            valid = valid and count >= 2
        ]]
    end

    -- pcall integrity self-check (runtime must actually return results).
    code = code .. [[
    local gmatch   = string.gmatch
    local err      = function() error(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;") end
    local _pcall   = pcall

    local pcallIntact2 = false
    local pcallIntact  = _pcall(function() pcallIntact2 = true end) and pcallIntact2
    valid = valid and pcallIntact

    local random    = math.random
    local tblconcat = table.concat
    local unpkg     = (table and table.unpack) or unpack
    local n         = random(3, 65)
    local acc1      = 0
    local acc2      = 0

    -- Baseline error message for line-number consistency checks.
    local pcallRet = {_pcall(function()
        local a = ]] .. tostring(math.random(1, 2^24)) .. [[ - "]] .. RandomStrings.randomString() .. [[" ^ ]] .. tostring(math.random(1, 2^24)) .. [[
        return "]] .. RandomStrings.randomString() .. [[" / a
    end)}
    local origMsg = pcallRet[2]
    local line    = tonumber(gmatch(tostring(origMsg), ':(%d*):')())

    for i = 1, n do
        local len       = random(1, 100)
        local n2        = random(0, 255)
        local pos       = random(1, len)
        local shouldErr = random(1, 2) == 1
        local msg       = origMsg:gsub(':(%d*):', ':' .. tostring(random(0, 10000)) .. ':')

        local arr = {_pcall(function()
            if random(1, 2) == 1 or i == n then
                local line2 = tonumber(gmatch(tostring(({_pcall(function()
                    local a = ]] .. tostring(math.random(1, 2^24)) .. [[ - "]] .. RandomStrings.randomString() .. [[" ^ ]] .. tostring(math.random(1, 2^24)) .. [[
                    return "]] .. RandomStrings.randomString() .. [[" / a
                end)})[2]), ':(%d*):')())
                valid = valid and (line == line2)
            end
            if shouldErr then
                error(msg, 0)
            end
            local arr2 = {}
            for j = 1, len do
                arr2[j] = random(0, 255)
            end
            arr2[pos] = n2
            return unpkg(arr2)
        end)}

        if shouldErr then
            valid = valid and (arr[1] == false) and (arr[2] == msg)
        else
            valid = valid and arr[1]
            acc1 = (acc1 + arr[pos + 1]) % 256
            acc2 = (acc2 + n2)           % 256
        end
    end
    valid = valid and (acc1 == acc2)

    if not valid then
        -- Crash: infinite loop with alternating error calls — no clean exit.
        while true do
            l1, l2 = l2, l1
            err()
        end
        return
    end
end

    -- Anti-Function-Arg-Hook: pass a metatable'd object through a no-op closure.
    -- If the executor intercepts __tostring on function arguments, err() fires.
    local obj = setmetatable({}, {
        __tostring = err,
    })
    obj[math.random(1, 100)] = obj
    ;(function() end)(obj)

    ]]

    local parsed = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code)
    local doStat = parsed.body.statements[1]
    doStat.body.scope:setParent(ast.body.scope)
    table.insert(ast.body.statements, 1, doStat)

    return ast
end

return AntiTamper
