-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- steps/LocalsToTable.lua
--
-- AST-level obfuscation step: hoists all local variable declarations into a
-- single shared table per function scope.  Every read and write of those
-- locals is rewritten as a table index operation, erasing the local-variable
-- ABI that static decompilers depend on.
--
-- Pure AST pass — works with any VM backend (Vmify, VmifyBC, VmifyLegacy)
-- or on its own without a VM step.

local Step     = require("ZukaTech.step");
local Ast      = require("ZukaTech.ast");
local Scope    = require("ZukaTech.scope");
local visitast = require("ZukaTech.visitast");
local logger   = require("logger");

local AstKind = Ast.AstKind;

local LocalsToTable = Step:extend();
LocalsToTable.Name        = "LocalsToTable";
LocalsToTable.Description =
    "Hoists all local variables into a shared table per function scope, " ..
    "rewriting reads/writes as table index operations. " ..
    "Pure AST pass — compatible with any VM backend.";

-- Settings -------------------------------------------------------------------

LocalsToTable.SettingsDescriptor = {
    TableKeyStyle = {
        type    = "enum";
        values  = {"number", "string"};
        default = "number";
        -- "number" -> t[1], t[2], ...   (compact)
        -- "string" -> t["_1"], t["_2"], ...  (avoids integer-key pattern matching)
    };
};

-- Helpers --------------------------------------------------------------------

local function makeKey(style, idx)
    if style == "string" then
        return Ast.StringExpression("_" .. idx);
    else
        return Ast.NumberExpression(idx);
    end
end

local function isFunctionNode(kind)
    return kind == AstKind.FunctionLiteralExpression
        or kind == AstKind.FunctionDeclaration
        or kind == AstKind.LocalFunctionDeclaration;
end

-- Step lifecycle -------------------------------------------------------------

function LocalsToTable:init() end

-- Core transform -------------------------------------------------------------

function LocalsToTable:apply(ast, pipeline)
    local style = self.TableKeyStyle or "number";

    -- One locals-table per *function* scope (not per block scope).
    -- funcTblScope[fs]          -> Scope that owns the table variable
    -- funcTblId[fs]             -> variable id of the table in that scope
    -- funcSlot[fs][declScope][id] -> integer slot assigned to that local
    -- funcSlotCount[fs]         -> next free slot index (1-based)
    local funcTblScope   = {};
    local funcTblId      = {};
    local funcSlot       = {};
    local funcSlotCount  = {};

    -- locked[scope][id] = true  ->  must NOT be moved into the table
    local locked = {};

    local function lock(scope, id)
        if scope and id then
            locked[scope] = locked[scope] or {};
            locked[scope][id] = true;
        end
    end

    local function isLocked(scope, id)
        return locked[scope] and locked[scope][id];
    end

    -- Register a function-body scope so it gets its own locals table.
    local function registerFuncScope(fscope)
        if funcTblScope[fscope] then return end;
        local tblId = fscope:addVariable();
        funcTblScope[fscope]  = fscope;
        funcTblId[fscope]     = tblId;
        funcSlot[fscope]      = {};
        funcSlotCount[fscope] = 0;
    end

    -- Return (funcScope, slot) for a local, or nil/nil to leave it alone.
    -- Walks up from declScope to find the nearest registered function scope.
    local function getSlot(declScope, id)
        if declScope.isGlobal then return nil, nil end;
        if isLocked(declScope, id) then return nil, nil end;

        local fscope = declScope;
        while fscope and not funcTblScope[fscope] do
            fscope = fscope.parentScope;
        end
        if not fscope then return nil, nil end;

        funcSlot[fscope][declScope] = funcSlot[fscope][declScope] or {};
        if not funcSlot[fscope][declScope][id] then
            funcSlotCount[fscope] = funcSlotCount[fscope] + 1;
            funcSlot[fscope][declScope][id] = funcSlotCount[fscope];
        end
        return fscope, funcSlot[fscope][declScope][id];
    end

    local function tableRead(fscope, slot, refScope)
        local tblScope = funcTblScope[fscope];
        local tblId    = funcTblId[fscope];
        refScope:addReferenceToHigherScope(tblScope, tblId);
        return Ast.IndexExpression(
            Ast.VariableExpression(tblScope, tblId),
            makeKey(style, slot)
        );
    end

    local function tableWrite(fscope, slot, refScope)
        local tblScope = funcTblScope[fscope];
        local tblId    = funcTblId[fscope];
        refScope:addReferenceToHigherScope(tblScope, tblId);
        return Ast.AssignmentIndexing(
            Ast.VariableExpression(tblScope, tblId),
            makeKey(style, slot)
        );
    end

    -- Pass 1: collect locks --------------------------------------------------
    visitast(ast, function(node, data)

        -- Function arguments live on the Lua call stack.
        if isFunctionNode(node.kind) then
            for _, arg in ipairs(node.args or {}) do
                if arg.kind == AstKind.VariableExpression then
                    lock(arg.scope, arg.id);
                end
            end
        end

        -- Numeric for counter: Lua manages this register internally.
        if node.kind == AstKind.ForStatement then
            lock(node.scope, node.id);
        end

        -- Generic for iteration variables.
        if node.kind == AstKind.ForInStatement then
            for _, id in ipairs(node.ids) do
                lock(node.scope, id);
            end
        end

        -- Multi-assignment LHS: rewriting a subset breaks arity.
        if node.kind == AstKind.AssignmentStatement and #node.lhs > 1 then
            for _, lv in ipairs(node.lhs) do
                if lv.kind == AstKind.AssignmentVariable then
                    lock(lv.scope, lv.id);
                end
            end
        end

        -- Multi-return declarations: last expr may yield >1 value.
        if node.kind == AstKind.LocalVariableDeclaration then
            local last = node.expressions[#node.expressions];
            local multiRet = last and (
                last.kind == AstKind.FunctionCallExpression or
                last.kind == AstKind.PassSelfFunctionCallExpression or
                last.kind == AstKind.VarargExpression
            );
            if multiRet or (#node.expressions < #node.ids) then
                for _, id in ipairs(node.ids) do
                    lock(node.scope, id);
                end
            end
        end

    end, function() end);

    -- Pass 2: register all function scopes first ------------------------------
    -- Must be a separate pass so getSlot() can always find a registered
    -- ancestor when we start rewriting in Pass 3.
    registerFuncScope(ast.body.scope);

    visitast(ast, function(node, data)
        if isFunctionNode(node.kind) and node.body then
            registerFuncScope(node.body.scope);
        end
    end, function() end);

    -- Pass 3: rewrite --------------------------------------------------------
    -- visitBlock splices multiple return values from postvisit in-place,
    -- so returning multiple statements from LocalVariableDeclaration works.
    visitast(ast, function() end, function(node, data)

        -- LocalVariableDeclaration -> one stmt per id (assignment or local)
        if node.kind == AstKind.LocalVariableDeclaration then
            local out = {};
            for i, id in ipairs(node.ids) do
                local fscope, slot = getSlot(node.scope, id);
                local expr = node.expressions[i] or Ast.NilExpression();
                if slot then
                    table.insert(out, Ast.AssignmentStatement(
                        { tableWrite(fscope, slot, data.scope) },
                        { expr }
                    ));
                else
                    table.insert(out, Ast.LocalVariableDeclaration(
                        node.scope, { id }, { expr }
                    ));
                end
            end
            if #out == 0 then return node end;
            return table.unpack(out);
        end

        -- VariableExpression (read) -> tbl[slot]
        if node.kind == AstKind.VariableExpression and not node.scope.isGlobal then
            local fscope, slot = getSlot(node.scope, node.id);
            if slot then
                return tableRead(fscope, slot, data.scope);
            end
        end

        -- AssignmentVariable (write target) -> tbl[slot]
        if node.kind == AstKind.AssignmentVariable and not node.scope.isGlobal then
            local fscope, slot = getSlot(node.scope, node.id);
            if slot then
                return tableWrite(fscope, slot, data.scope);
            end
        end

        -- LocalFunctionDeclaration -> tbl[slot] = function(...)
        if node.kind == AstKind.LocalFunctionDeclaration then
            local fscope, slot = getSlot(node.scope, node.id);
            if slot then
                local funcLit = Ast.FunctionLiteralExpression(node.args, node.body);
                return Ast.AssignmentStatement(
                    { tableWrite(fscope, slot, data.scope) },
                    { funcLit }
                );
            end
        end

    end);

    -- Pass 4: inject table declarations --------------------------------------
    -- Slot counts are now final.  Prepend `local tbl = {nil,...}` directly
    -- into each function block — no re-visit needed, no risk of double inject.
    local function injectIntoBlock(block, fscope)
        if not funcTblScope[fscope] then return end;
        local count = funcSlotCount[fscope];
        if count == 0 then return end;

        local tblScope = funcTblScope[fscope];
        local tblId    = funcTblId[fscope];

        local entries = {};
        for i = 1, count do
            table.insert(entries, Ast.TableEntry(Ast.NilExpression()));
        end

        table.insert(block.statements, 1,
            Ast.LocalVariableDeclaration(
                tblScope,
                { tblId },
                { Ast.TableConstructorExpression(entries) }
            )
        );
    end

    injectIntoBlock(ast.body, ast.body.scope);

    -- Walk to inject into every function body (previsit only — no re-rewriting).
    visitast(ast, function(node, data)
        if isFunctionNode(node.kind) and node.body then
            injectIntoBlock(node.body, node.body.scope);
        end
    end, function() end);

    logger:info("[LocalsToTable] Local variables hoisted into table slots.");
end

return LocalsToTable;
