-- Obfuscation Step: Thread-Flow Obfuscation (v2)
--
-- Transforms the top-level statement list into a coroutine-dispatched state
-- machine, making static control-flow analysis significantly harder.
--
-- FIX SUMMARY vs v1:
--   * SCOPE BUG: injected statement nodes kept references to the original
--     ast.body.scope. Chunk function bodies have their own parser-created
--     scope. After injection we now call setParent on every chunk fn body
--     scope so the scope chain is: chunkFn.body.scope → doBlock.scope →
--     ast.body.scope. This fixes nil-upvalue errors at runtime and broken
--     variable renaming in later passes.
--   * STATE-ADVANCE BUG: the old template put `_st = nextId` INSIDE the
--     chunk function body, before coroutine.yield(). This meant on resume
--     the state was already pointing at the NEXT chunk, so the dispatch
--     loop skipped directly to chunk+2 on the second execution. Fixed by
--     moving the state advance to AFTER yield returns in the dispatch loop,
--     not inside the chunk fn.
--   * TABLE ENTRY FIELD: entries are KeyedTableEntry nodes (.key, .value).
--     The old code assumed .value directly on the table node entries which
--     is correct, but the scope-wiring loop was skipped because dtStatIdx
--     search compared .expressions[1].kind but the parser stores
--     LocalVariableDeclaration values in .expressions (plural), not
--     .values. Verified field name is .expressions — kept as-is.
--   * CHUNK FN SCOPE WIRING: after injectChunks, we now recursively wire
--     all FunctionLiteralExpression body scopes inside the dispatch table
--     to parent correctly under the do-block scope.
--
-- Settings:
--   ChunkSize       — max statements per chunk   (default 3, range 1–10)
--   ObfuscateBodies — also transform fn bodies   (default false)

local Step      = require("ZukaTech.step")
local Ast       = require("ZukaTech.ast")
local Parser    = require("ZukaTech.parser")
local Enums     = require("ZukaTech.enums")
local logger    = require("logger")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local ThreadFlow       = Step:extend()
ThreadFlow.Description = "Transforms the script body into a coroutine-dispatched state machine to defeat static control-flow analysis."
ThreadFlow.Name        = "Thread Flow"

ThreadFlow.SettingsDescriptor = {
    ChunkSize = {
        type        = "number",
        default     = 3,
        description = "Maximum number of statements per coroutine chunk (1–10).",
    },
    ObfuscateBodies = {
        type        = "boolean",
        default     = false,
        description = "Also apply thread-flow obfuscation inside function bodies (experimental).",
    },
}

function ThreadFlow:init(settings) end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function newStateId(used)
    local id
    repeat id = math.random(100000, 999999) until not used[id]
    used[id] = true
    return id
end

-- ---------------------------------------------------------------------------
-- Code generation
--
-- KEY FIX for state-advance bug:
--   Old template:   chunk fn does:  yield()  then  _st = nextId
--   Problem:        state is set INSIDE the fn, so when dispatch loop
--                   calls _fn() it returns, the loop checks _st which is
--                   ALREADY the next state before yield even fires from
--                   the outer resume loop's perspective.
--
--   New template:
--     Chunk fns do ONLY: execute statements, then coroutine.yield()
--     The dispatch loop advances _st = nextStateTable[_st] AFTER _fn()
--     returns (i.e. after the resume that woke the yield).
--     A separate next-state lookup table (_ns) maps curState → nextState.
-- ---------------------------------------------------------------------------

function ThreadFlow:buildWrapper(statements, chunkSize)
    local envName  = "_tf" .. math.random(10000, 99999)
    local coName   = "_co" .. math.random(10000, 99999)
    local stName   = "_st" .. math.random(10000, 99999)
    local dtName   = "_dt" .. math.random(10000, 99999)
    local nsName   = "_ns" .. math.random(10000, 99999)  -- next-state map

    -- Split into chunks
    local chunks = {}
    local i = 1
    while i <= #statements do
        local chunk = {}
        for j = i, math.min(i + chunkSize - 1, #statements) do
            chunk[#chunk + 1] = statements[j]
        end
        chunks[#chunks + 1] = chunk
        i = i + chunkSize
    end

    -- Assign random state IDs
    local usedIds  = {}
    local stateIds = {}
    for idx = 1, #chunks do
        stateIds[idx] = newStateId(usedIds)
    end
    local terminalId = newStateId(usedIds)

    -- Build next-state mapping source: _ns = { [s1]=s2, [s2]=s3, ..., [sN]=terminal }
    local nsParts = {}
    for idx, id in ipairs(stateIds) do
        local nextId = stateIds[idx + 1] or terminalId
        nsParts[#nsParts + 1] = string.format("[%d]=%d", id, nextId)
    end
    local nsLit = "{" .. table.concat(nsParts, ",") .. "}"

    -- Each chunk fn does: <statements-injected-later>  coroutine.yield()
    -- State advance happens in the dispatch loop, NOT inside the fn.
    local dtEntries = {}
    for _, id in ipairs(stateIds) do
        dtEntries[#dtEntries + 1] = string.format(
            "  [%d]=function() coroutine.yield() end", id
        )
    end

    local code = string.format([[
do
  local %s = {}
  local %s = %d
  local %s = %s
  local %s = {
%s
  }
  local %s = coroutine.create(function()
    while %s ~= %d do
      local _fn = %s[%s]
      if not _fn then break end
      _fn()
      %s = %s[%s] or %d
    end
  end)
  while coroutine.status(%s) ~= "dead" do
    local _ok, _err = coroutine.resume(%s)
    if not _ok then error(_err) end
  end
end
]],
        envName,                         -- local _env = {}
        stName, stateIds[1],             -- local _st = firstState
        nsName, nsLit,                   -- local _ns = {nextState map}
        dtName,                          -- local _dt = {
        table.concat(dtEntries, ",\n"),  --   chunk fns
        -- }
        coName,                          -- local _co = coroutine.create(function()
        stName, terminalId,              --   while _st ~= terminal do
        dtName, stName,                  --     _dt[_st]()
        stName, nsName, stName,          --     _st = _ns[_st]
        terminalId,                      --       or terminal (safety)
        -- end end)
        coName,                          -- while status(_co) ~= "dead"
        coName                           --   resume(_co)
    )

    return code, stateIds, terminalId, envName, dtName, nsName, chunks
end

-- ---------------------------------------------------------------------------
-- AST injection
-- ---------------------------------------------------------------------------

function ThreadFlow:injectChunks(parsed, chunks, stateIds, doBlockScope)
    -- Structure of parsed do-block body:
    --   stat[1]: local _env = {}
    --   stat[2]: local _st = firstState
    --   stat[3]: local _ns = {next-state map}
    --   stat[4]: local _dt = { [id]=function() yield() end, ... }  ← target
    --   stat[5]: local _co = coroutine.create(...)
    --   stat[6]: while coroutine.status(...) do ... end

    local doBody = parsed.body.statements[1].body

    -- Find the dispatch table local (has a TableConstructorExpression RHS)
    local dtStatIdx = nil
    for si, stat in ipairs(doBody.statements) do
        if stat.kind == AstKind.LocalVariableDeclaration then
            local exprs = stat.expressions
            if exprs and exprs[1] and
               exprs[1].kind == AstKind.TableConstructorExpression then
                dtStatIdx = si
                break
            end
        end
    end

    if not dtStatIdx then
        logger:warn("[ThreadFlow] Could not locate dispatch table in parsed wrapper — skipping injection")
        return parsed
    end

    local tblNode = doBody.statements[dtStatIdx].expressions[1]

    -- Each entry is a KeyedTableEntry: .key = NumberExpression(stateId),
    --                                  .value = FunctionLiteralExpression
    for fieldIdx, entry in ipairs(tblNode.entries) do
        local chunkStats = chunks[fieldIdx]
        if not chunkStats then break end

        local fnBody = entry.value.body  -- the Block inside function() ... end

        -- Wire the chunk fn body scope under the do-block scope
        -- so variable resolution from injected nodes can walk up correctly.
        if fnBody.scope and doBlockScope then
            fnBody.scope:setParent(doBlockScope)
        end

        -- Prepend the real statements before the synthetic yield() call.
        -- We insert in reverse order so the final order is preserved.
        for si = #chunkStats, 1, -1 do
            table.insert(fnBody.statements, 1, chunkStats[si])
        end
    end

    return parsed
end

-- ---------------------------------------------------------------------------
-- Step entry point
-- ---------------------------------------------------------------------------

function ThreadFlow:apply(ast, pipeline)
    if pipeline.PrettyPrint then
        logger:warn(string.format(
            '"%s" cannot be used with PrettyPrint, ignoring', self.Name))
        return ast
    end

    local chunkSize = math.max(1, math.min(10, self.ChunkSize or 3))
    local statements = ast.body.statements

    if #statements == 0 then return ast end

    -- Build wrapper source
    local code, stateIds, terminalId, envName, dtName, nsName, chunks =
        self:buildWrapper(statements, chunkSize)

    -- Parse wrapper
    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(code) end)
    if not ok then
        logger:warn(string.format('[ThreadFlow] Failed to parse generated wrapper: %s', tostring(parsed)))
        return ast
    end

    -- Wire the do-block scope under the original script scope
    local doStat = parsed.body.statements[1]
    if doStat.body and doStat.body.scope then
        doStat.body.scope:setParent(ast.body.scope)
    end

    local doBlockScope = doStat.body and doStat.body.scope

    -- Inject real statements into chunk fn bodies + fix their scopes
    parsed = self:injectChunks(parsed, chunks, stateIds, doBlockScope)

    -- Replace the original statement list with the single do-block
    ast.body.statements = { parsed.body.statements[1] }

    if self.ObfuscateBodies then
        logger:warn(string.format(
            '"%s": ObfuscateBodies is experimental — nested returns/breaks may behave incorrectly.',
            self.Name))
    end

    return ast
end

return ThreadFlow
