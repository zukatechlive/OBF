-- Obfuscation Step: Compressor
--
-- Ports the Compressor from NewThingsToAdd into the Zuraph pipeline.
-- Strips comments (both -- and --[[ ]]) and collapses all unnecessary
-- whitespace from the unparsed source, making the final output leaner
-- and harder to manually read.
--
-- Notes:
--   * String literals (single, double, and long-bracket) are preserved
--     verbatim so nothing breaks at runtime.
--   * Lua keywords are temporarily "escaped" with placeholder tokens
--     during the whitespace-collapse phase so they never accidentally
--     merge with adjacent identifiers.
--   * Safe to run as a final post-pass (place it last in the pipeline).

local Step = require("ZukaTech.step")
local Ast  = require("ZukaTech.ast")

local Compressor       = Step:extend()
Compressor.Description = "Strips comments and collapses whitespace in the final source output."
Compressor.Name        = "Compressor"

Compressor.SettingsDescriptor = {
    MinLength = {
        type    = "number",
        default = 10,
        min     = 0,
        max     = 1e9,
    },
}

-- ── Internal compressor logic (ported from NewThingsToAdd/compressor.lua) ──

local LUA_KEYWORDS = {
    "and","break","do","else","elseif","end","false","for","function",
    "goto","if","in","local","nil","not","or","repeat","return",
    "then","true","until","while"
}

local KW_PRE  = "@@KW_"
local KW_POST = "_KW@@"
local ST_PRE  = "@@S_"
local ST_POST = "_S@@"

local function compress(code, minLength)
    if type(code) ~= "string" then return code end
    if #code < (minLength or 10) then return code end

    local strings      = {}
    local string_count = 0
    local keywords_map = {}

    -- Preserve string literals ------------------------------------------------
    local function preserveStrings(c)
        -- Long-bracket strings  [=*[...]=*]
        c = c:gsub("%[(=*)%[(.-)%]%1%]", function(equals, str)
            string_count = string_count + 1
            local key = ST_PRE .. string_count .. ST_POST
            strings[key] = "[" .. equals .. "[" .. str .. "]" .. equals .. "]"
            return key
        end)
        -- Double-quoted strings
        c = c:gsub('"(.-)"', function(str)
            if str:find(ST_PRE, 1, true) then return '"' .. str .. '"' end
            string_count = string_count + 1
            local key = ST_PRE .. string_count .. ST_POST
            strings[key] = '"' .. str .. '"'
            return key
        end)
        -- Single-quoted strings
        c = c:gsub("('.-')", function(str)
            if str:find(ST_PRE, 1, true) then return str end
            string_count = string_count + 1
            local key = ST_PRE .. string_count .. ST_POST
            strings[key] = str
            return key
        end)
        return c
    end

    -- Escape keywords so they cannot merge with neighbours --------------------
    local function preserveKeywords(c)
        for _, kw in ipairs(LUA_KEYWORDS) do
            local ph = KW_PRE .. kw .. KW_POST
            keywords_map[ph] = kw
            c = c:gsub("([^%w_])(" .. kw .. ")([^%w_])", "%1" .. ph .. "%3")
            c = c:gsub("^(" .. kw .. ")([^%w_])", ph .. "%2")
            c = c:gsub("([^%w_])(" .. kw .. ")$", "%1" .. ph)
            c = c:gsub("^(" .. kw .. ")$", ph)
        end
        return c
    end

    local function restoreKeywords(c)
        for ph, kw in pairs(keywords_map) do
            c = c:gsub(ph, function() return kw end)
        end
        return c
    end

    local function restoreStrings(c)
        for i = string_count, 1, -1 do
            local key = ST_PRE .. i .. ST_POST
            c = c:gsub(key, function() return strings[key] end)
        end
        return c
    end

    -- Transformation passes ---------------------------------------------------
    code = preserveStrings(code)
    code = preserveKeywords(code)

    -- Strip block comments then line comments
    code = code:gsub("%-%-%[%[.-%]%]", "")
    code = code:gsub("%-%-[^\n]*", "")

    -- Collapse newlines and excess whitespace
    code = code:gsub("[\n\r]+", " ")
    code = code:gsub("%s+", " ")

    -- Remove spaces around operators and punctuation
    code = code:gsub("%s*%.%.%s*", "..")
    code = code:gsub("%s*([%+%-%*/%%\\^#%<%>%~%=%,%;:%(%){}%[%]])%s*", "%1")
    code = code:gsub("%s*%.%s*", ".")
    code = code:gsub("%.%.", "..")   -- re-protect concat after dot-strip

    -- Trim
    code = code:match("^%s*(.-)%s*$") or ""

    code = restoreKeywords(code)
    code = restoreStrings(code)

    return code
end

-- ── Step interface ──────────────────────────────────────────────────────────

function Compressor:init(settings) end

-- The Compressor works on the final source string, not the AST.
-- We store the min-length threshold and expose a :compressSource() helper
-- that pipeline.lua (or the CLI) can call after unparsing.
-- We also implement :apply() as a no-op so it fits seamlessly into the
-- standard pipeline; calling compress after unparse is handled via the
-- postProcess hook below.

function Compressor:apply(ast, pipeline)
    -- Tag the pipeline so the CLI wrapper knows to compress post-unparse.
    pipeline._compressorStep = self
    return ast
end

-- Called by the pipeline / CLI after the source has been unparsed.
function Compressor:compressSource(source)
    return compress(source, self.MinLength)
end

return Compressor
