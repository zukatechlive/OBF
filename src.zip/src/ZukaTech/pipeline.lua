-- pipeline.lua
-- Configurable obfuscation pipeline

local config   = require("config")
local Ast      = require("ZukaTech.ast")
local Enums    = require("ZukaTech.enums")
local util     = require("ZukaTech.util")
local Parser   = require("ZukaTech.parser")
local Unparser = require("ZukaTech.unparser")
local logger   = require("logger")

local NameGenerators = require("ZukaTech.namegenerators")
local Steps          = require("ZukaTech.steps")

local lookupify  = util.lookupify
local LuaVersion = Enums.LuaVersion
local AstKind    = Ast.AstKind

-- ── Time helper ───────────────────────────────────────────────────────────
-- os.clock() on Windows measures CPU time not wall time, so use os.time() elsewhere.
-- For sub-second accuracy on non-Windows we prefer socket.gettime if available.
local _winplatform = package and package.config
	and type(package.config) == "string"
	and package.config:sub(1, 1) == "\\"

local _socketTime = (not _winplatform) and pcall(function()
	local socket = require("socket")
	gettime = socket.gettime
end)

local function gettime()
	if _winplatform then
		return os.clock()
	end
	return os.time()
end

-- ── Pipeline ──────────────────────────────────────────────────────────────
local Pipeline = {
	NameGenerators  = NameGenerators,
	Steps           = Steps,
	DefaultSettings = {
		LuaVersion    = LuaVersion.LuaU,
		PrettyPrint   = false,
		Seed          = 0,
		VarNamePrefix = "",
	},
}
Pipeline.__index = Pipeline -- set once here, not repeated in :new()

-- ── Internal helpers ───────────────────────────────────────────────────────
local function resolveConventions(luaVersion)
	local conventions = Enums.Conventions[luaVersion]
	if not conventions then
		logger:error(string.format(
			"The Lua version \"%s\" is not recognised. Valid versions: \"%s\"",
			luaVersion, table.concat(util.keys(Enums.Conventions), '", "')))
	end
	return conventions
end

-- ── Constructor ───────────────────────────────────────────────────────────
function Pipeline:new(settings)
	settings = settings or {}
	local luaVersion  = settings.luaVersion or settings.LuaVersion or Pipeline.DefaultSettings.LuaVersion
	local conventions = resolveConventions(luaVersion)
	local prettyPrint = settings.PrettyPrint   or Pipeline.DefaultSettings.PrettyPrint
	local prefix      = settings.VarNamePrefix or Pipeline.DefaultSettings.VarNamePrefix
	local seed        = settings.Seed          or Pipeline.DefaultSettings.Seed

	local pipeline = setmetatable({
		LuaVersion    = luaVersion,
		PrettyPrint   = prettyPrint,
		VarNamePrefix = prefix,
		Seed          = seed,
		conventions   = conventions,
		steps         = {},
		namegenerator = nil,
		parser = Parser:new({ LuaVersion = luaVersion }),
		unparser = Unparser:new({
			LuaVersion  = luaVersion,
			PrettyPrint = prettyPrint,
			Highlight   = settings.Highlight,
		}),
	}, self)

	return pipeline
end

-- ── From config ───────────────────────────────────────────────────────────
function Pipeline:fromConfig(cfg)
	cfg = cfg or {}
	local pipeline = Pipeline:new({
		LuaVersion    = cfg.LuaVersion    or LuaVersion.Lua51,
		PrettyPrint   = cfg.PrettyPrint   or false,
		VarNamePrefix = cfg.VarNamePrefix or "",
		Seed          = cfg.Seed          or 0,
	})

	pipeline:setNameGenerator(cfg.NameGenerator or "Mangled")

	for _, step in ipairs(cfg.Steps or {}) do
		if type(step.Name) ~= "string" then
			logger:error("Step.Name must be a string")
		end
		local constructor = pipeline.Steps[step.Name]
		if not constructor then
			logger:error(string.format("Step \"%s\" was not found!", step.Name))
		end
		pipeline:addStep(constructor:new(step.Settings or {}))
	end

	return pipeline
end

-- ── Step management ───────────────────────────────────────────────────────
function Pipeline:addStep(step)
	table.insert(self.steps, step)
end

function Pipeline:resetSteps()
	self.steps = {}
end

function Pipeline:getSteps()
	return self.steps
end

-- ── Options ───────────────────────────────────────────────────────────────
function Pipeline:setOption(name, value)
	if Pipeline.DefaultSettings[name] ~= nil then
		self[name] = value
	else
		logger:error(string.format("\"%s\" is not a valid pipeline option", tostring(name)))
	end
end

function Pipeline:setLuaVersion(luaVersion)
	local conventions = resolveConventions(luaVersion)
	self.conventions = conventions
	self.parser   = Parser:new({ LuaVersion = luaVersion })
	self.unparser = Unparser:new({ LuaVersion = luaVersion })
	self.LuaVersion = luaVersion
end

function Pipeline:getLuaVersion()
	return self.LuaVersion -- was returning self.luaVersion (lowercase) — bug fix
end

-- ── Name generator ────────────────────────────────────────────────────────
function Pipeline:setNameGenerator(nameGenerator)
	if type(nameGenerator) == "string" then
		local resolved = Pipeline.NameGenerators[nameGenerator]
		if not resolved then
			local available = {}
			for k in pairs(Pipeline.NameGenerators) do
				available[#available + 1] = k
			end
			table.sort(available)
			logger:error(string.format(
				"NameGenerator \"%s\" not found. Available: %s",
				nameGenerator, table.concat(available, ", ")))
		end
		nameGenerator = resolved
	end

	if type(nameGenerator) == "function" or type(nameGenerator) == "table" then
		self.namegenerator = nameGenerator
	else
		logger:error("setNameGenerator: argument must be a generator name string or generator table")
	end
end

-- ── Apply ─────────────────────────────────────────────────────────────────
function Pipeline:apply(code, filename)
	local startTime = gettime()
	filename = filename or "Anonymous Script"

	logger:info(string.format("Processing %s ...", filename))

	-- Seed RNG
	math.randomseed(self.Seed > 0 and self.Seed or os.time())

	-- Parse
	logger:info("Parsing ...")
	local parserStart = gettime()
	local sourceLen   = #code
	local ast         = self.parser:parse(code)
	logger:info(string.format("Parsing done in %.2f seconds", gettime() - parserStart))

	-- User-defined steps
	for _, step in ipairs(self.steps) do
		local stepStart = gettime()
		logger:info(string.format("Step: %s", step.Name or "unnamed"))
		local newAst = step:apply(ast, self)
		if type(newAst) == "table" then
			ast = newAst
		end
		logger:info(string.format("Step done in %.2f seconds", gettime() - stepStart))
	end

	-- Rename variables
	self:renameVariables(ast)

	-- Unparse to source
	code = self:unparse(ast)

	-- ── Ordered post-unparse passes ───────────────────────────────────────
	-- Order matters: VariableRenamer → BytecodeEncoder → Compressor →
	--                BlobCompress → CrewmateFormat → ZukaZalgo
	local postPasses = {
		{ field = "_varRenamerStep",     label = "VariableRenamer", fn = "process" },
		{ field = "_bytecodeEncoderStep",label = "BytecodeEncoder", fn = "process" },
	}

	for _, pass in ipairs(postPasses) do
		local step = self[pass.field]
		if step then
			logger:info(string.format("Running %s post-pass ...", pass.label))
			code = step[pass.fn](step, code)
			logger:info(string.format("%s done.", pass.label))
		end
	end

	-- Compression passes (log ratio)
	local compressionPasses = {
		{ field = "_compressorStep",  label = "Compressor",   fn = "compressSource" },
		{ field = "_blobCompressStep",label = "BlobCompress", fn = "compressSource" },
	}

	for _, pass in ipairs(compressionPasses) do
		local step = self[pass.field]
		if step then
			logger:info(string.format("Running %s post-pass ...", pass.label))
			local preLen = #code
			code = step[pass.fn](step, code)
			logger:info(string.format(
				"%s: %.1f%% → %.1f%% of input",
				pass.label, (preLen / sourceLen) * 100, (#code / sourceLen) * 100))
		end
	end

	-- Format / visual passes (must run after compression)
	local formatPasses = {
		{ field = "_crewmateFormatStep", label = "CrewmateFormat", fn = "process" },
		{ field = "_zalgoStep",          label = "ZukaZalgo",      fn = "process" },
	}

	for _, pass in ipairs(formatPasses) do
		local step = self[pass.field]
		if step then
			logger:info(string.format("Running %s post-pass ...", pass.label))
			code = step[pass.fn](step, code)
			logger:info(string.format("%s done.", pass.label))
		end
	end

	-- Summary
	local elapsed = gettime() - startTime
	logger:info(string.format("Done in %.2f seconds", elapsed))
	logger:info(string.format("Output is %.2f%% of input size", (#code / sourceLen) * 100))

	return code
end

-- ── Unparse ───────────────────────────────────────────────────────────────
function Pipeline:unparse(ast)
	local startTime = gettime()
	logger:info("Generating output ...")
	local unparsed = self.unparser:unparse(ast)
	logger:info(string.format("Output generated in %.2f seconds", gettime() - startTime))
	return unparsed
end

-- ── Rename variables ──────────────────────────────────────────────────────
function Pipeline:renameVariables(ast)
	local startTime = gettime()
	logger:info("Renaming ...")

	local generatorFunction = self.namegenerator or Pipeline.NameGenerators.Mangled
	if type(generatorFunction) == "table" then
		if type(generatorFunction.prepare) == "function" then
			generatorFunction.prepare(ast)
		end
		generatorFunction = generatorFunction.generateName
	end

	local prefix = self.VarNamePrefix
	if #prefix ~= 0 and not self.unparser:isValidIdentifier(prefix) then
		logger:error(string.format(
			"The prefix \"%s\" is not a valid identifier in %s", prefix, self.LuaVersion))
	end

	ast.globalScope:renameVariables({
		Keywords     = self.conventions.Keywords,
		generateName = generatorFunction,
		prefix       = prefix,
	})

	logger:info(string.format("Renaming done in %.2f seconds", gettime() - startTime))
end

return Pipeline