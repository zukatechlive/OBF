-- namegenerators/regasm.lua
-- Generates names styled like fake assembly registers/operands
-- e.g. r0x4F, op2C, imm3A, _v1B, sp4F

local util = require("ZukaTech.util")

local seed   = 0
local offset = 0

-- prefix pools — short, assembly-flavored
local prefixes = {"r", "op", "imm", "v", "sp", "bp", "ax", "cx", "dx", "t"}

local function hashVal(id)
    return (id * 2654435761 + seed * 0x1F3D7) % 0xFFFFFF
end

local function generateName(id, scope)
    id = id + offset
    local v      = hashVal(id)
    local pre    = prefixes[(v % #prefixes) + 1]
    local hex    = string.format("%02X", v % 0xFF)
    local suffix = string.format("%X", (v * 31 + id) % 0xF)
    return pre .. hex .. suffix
end

local function prepare(ast)
    util.shuffle(prefixes)
    seed   = math.random(0, 0xFFFF)
    offset = math.random(0, 9999)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
