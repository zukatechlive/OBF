local util  = require("ZukaTech.util")
local bit32 = require("ZukaTech.bit").bit32
local band   = bit32.band
local bxor   = bit32.bxor
local lshift = bit32.lshift
local rshift = bit32.rshift
local MIN_LEN = 4
local MAX_LEN = 8
local ALPHA  = {}
local ALNUM  = {}
local DIGITS = {}
do
    for c = 65, 90 do
        local ch = string.char(c)
        ALPHA[#ALPHA+1]   = ch
        ALNUM[#ALNUM+1]   = ch
    end
    for c = 97, 122 do
        local ch = string.char(c)
        ALPHA[#ALPHA+1]   = ch
        ALNUM[#ALNUM+1]   = ch
    end
    for c = 48, 57 do
        local ch = string.char(c)
        ALNUM[#ALNUM+1]   = ch
        DIGITS[#DIGITS+1] = ch
    end
end
local seed  = 0
local saltA = 0
local saltB = 0
local usedNames = {}
local function lcg(n, salt)
    n = band(n, 0xFFFFFFFF)
    n = bxor(n, lshift(n, 13))
    n = bxor(n, rshift(n, 7))
    n = bxor(n, lshift(n, 17))
    return band(n * 1664525 + salt, 0xFFFFFFFF)
end
local function _buildName(id)
    local s1 = lcg(id,                seed + saltA)
    local s2 = lcg(bxor(s1, saltB),   seed + id)
    local s3 = lcg(s2 + saltA,        id  * saltB + 1)
    local len  = MIN_LEN + (s1 % (MAX_LEN - MIN_LEN + 1))
    local name = "_"
    name = name .. ALPHA[(s2 % #ALPHA) + 1]
    for i = 1, len - 1 do
        local h = lcg(s3 + i * 31 + id, bxor(saltA, i * saltB + seed))
        local pool
        if   h % 12 < 5  then pool = DIGITS
        elseif h % 12 < 10 then pool = ALNUM
        else                    pool = ALPHA
        end
        name = name .. pool[(h % #pool) + 1]
    end
    return name
end
local function generateName(id, scope, originalName)
    local name
    local attempt = id
    local tries = 0
    repeat
        name   = _buildName(attempt)
        attempt = attempt + 0x8000
        tries  = tries + 1
        if tries > 64 then
            name = "_v" .. tostring(id) .. tostring(attempt % 0xFFFF)
            break
        end
    until not usedNames[name]
    usedNames[name] = true
    return name
end
local function prepare(ast)
    local t = (os.time()  or 0) % 0x7FFFFFFF
    local c = math.floor((os.clock() * 1e6)) % 0x7FFFFFFF
    seed  = (t * 1664525 + c * 22695477 + math.random(0, 0xFFFF)) % 0xFFFFFF
    saltA = (math.random(1, 0xFFFF) * 2) - 1
    saltB = math.random(0x1000, 0xFFFF)
    usedNames = {}
end
return {
    generateName = generateName,
    prepare      = prepare,
}