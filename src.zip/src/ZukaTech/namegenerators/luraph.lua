-- ZukaTech Obfuscator — namegenerators/luraph.lua
--
-- Replicates the naming strategy observed in Luraph v14:
--
--   • Global/short names  → pure base-63 counter (shortest possible ids)
--     e.g.  A, B … z, _, A0, A1, Aa, Ab …
--
--   • Per-scope names     → random 3-5 char alphanumeric base prefix
--     + base-63 counter suffix appended for each new name in that scope
--     e.g.  dOr, dOrK, dOrL, dOrKH, dOrKHVn …
--
-- Full 63-char charset: 0-9 A-Z a-z _
-- No lookalike filtering (Luraph keeps 0/O, 1/l/I etc.)

local util = require("ZukaTech.util")

-- ────────────────────────────────────────────────
-- Charset
-- ────────────────────────────────────────────────

-- Tail charset (all 63 chars — used after position 1)
local TAIL_CHARS = {}
do
    for i = 0, 9   do TAIL_CHARS[#TAIL_CHARS + 1] = tostring(i) end  -- 0-9
    for i = 65, 90 do TAIL_CHARS[#TAIL_CHARS + 1] = string.char(i) end -- A-Z
    for i = 97,122 do TAIL_CHARS[#TAIL_CHARS + 1] = string.char(i) end -- a-z
    TAIL_CHARS[#TAIL_CHARS + 1] = "_"
end
local TAIL_BASE = #TAIL_CHARS  -- 63

-- Head charset (letters + underscore only — valid Lua identifier start)
local HEAD_CHARS = {}
do
    for i = 65, 90 do HEAD_CHARS[#HEAD_CHARS + 1] = string.char(i) end -- A-Z
    for i = 97,122 do HEAD_CHARS[#HEAD_CHARS + 1] = string.char(i) end -- a-z
    HEAD_CHARS[#HEAD_CHARS + 1] = "_"
end
local HEAD_BASE = #HEAD_CHARS  -- 53

-- ────────────────────────────────────────────────
-- LCG RNG (same multiplier family used across ZukaTech)
-- ────────────────────────────────────────────────

local _seed = 92518

local function _lcg()
    _seed = (_seed * 1664525 + 1013904223) % 0x7FFFFFFF
    return _seed
end

local function _randInt(range)
    return _lcg() % range
end

-- ────────────────────────────────────────────────
-- Base-63 counter → string
-- Encodes n ≥ 0 as a variable-length base-63 string.
-- Position 0 uses HEAD_CHARS so the result is always a valid identifier.
-- ────────────────────────────────────────────────

local function _encodeCounter(n)
    -- First character from HEAD_CHARS (no digits/no leading digit issue)
    local head_idx = n % HEAD_BASE
    n = math.floor(n / HEAD_BASE)
    local result = HEAD_CHARS[head_idx + 1]

    -- Remaining characters from TAIL_CHARS
    while n > 0 do
        local tail_idx = (n - 1) % TAIL_BASE
        n = math.floor((n - 1) / TAIL_BASE)
        result = result .. TAIL_CHARS[tail_idx + 1]
    end

    return result
end

-- ────────────────────────────────────────────────
-- Random base-string generator (scope prefix)
-- 3-5 chars, first char from HEAD_CHARS, rest from TAIL_CHARS
-- ────────────────────────────────────────────────

local function _randomBase()
    local len = _randInt(3) + 3  -- 3, 4, or 5
    local s = HEAD_CHARS[_randInt(HEAD_BASE) + 1]
    for _ = 2, len do
        s = s .. TAIL_CHARS[_randInt(TAIL_BASE) + 1]
    end
    return s
end

-- ────────────────────────────────────────────────
-- Per-run state
-- ────────────────────────────────────────────────

-- Global counter for short/global names (no scope prefix)
local _globalCounter = 0

-- Per-scope state: scopeKey → { base, counter, usedNames }
local _scopes = {}

-- Global used-name registry (collision guard across all scopes)
local _globalUsed = {}

-- Reserved Lua keywords — must never be emitted as identifiers
local RESERVED = {
    ["and"]=true,["break"]=true,["do"]=true,["else"]=true,["elseif"]=true,
    ["end"]=true,["false"]=true,["for"]=true,["function"]=true,["if"]=true,
    ["in"]=true,["local"]=true,["nil"]=true,["not"]=true,["or"]=true,
    ["repeat"]=true,["return"]=true,["then"]=true,["true"]=true,
    ["until"]=true,["while"]=true,
}

local function _resetState()
    _globalCounter = 0
    _scopes        = {}
    _globalUsed    = {}
end

-- ────────────────────────────────────────────────
-- Scope key helper (mirrors other generators)
-- ────────────────────────────────────────────────

local function _scopeKey(scope)
    if scope == nil then return "global" end
    if type(scope) == "table" then return tostring(scope) end
    return tostring(scope)
end

local function _scopeLevel(scope)
    if type(scope) == "table" then
        return tonumber(scope.level or scope.depth or 0) or 0
    elseif type(scope) == "number" then
        return scope
    end
    return 0
end

-- ────────────────────────────────────────────────
-- Scope initialiser — lazily create a scope entry
-- ────────────────────────────────────────────────

local function _getScope(key)
    if not _scopes[key] then
        -- Generate a random base; retry on collision with existing bases
        local base
        local tries = 0
        repeat
            base = _randomBase()
            tries = tries + 1
        until not _globalUsed[base] or tries > 32
        _scopes[key] = { base = base, counter = 0 }
        -- Reserve the bare base itself so no name ever equals just the base
        _globalUsed[base] = true
    end
    return _scopes[key]
end

-- ────────────────────────────────────────────────
-- Name builders
-- ────────────────────────────────────────────────

-- Short/global style: pure base-63 counter, no prefix
-- Produces: A B C … z _ A0 A1 … (shortest identifiers first)
local function _buildGlobal()
    local name
    local tries = 0
    repeat
        name = _encodeCounter(_globalCounter)
        _globalCounter = _globalCounter + 1
        tries = tries + 1
    until (not _globalUsed[name] and not RESERVED[name]) or tries > 256
    return name
end

-- Scoped style: scope's random base + base-63 counter suffix
-- Produces: dOr dOrK dOrL dOrKH … (matches Luraph structure exactly)
local function _buildScoped(scopeEntry)
    local name
    local tries = 0
    repeat
        local suffix = _encodeCounter(scopeEntry.counter)
        scopeEntry.counter = scopeEntry.counter + 1
        name = scopeEntry.base .. suffix
        tries = tries + 1
    until (not _globalUsed[name] and not RESERVED[name]) or tries > 256
    return name
end

-- ────────────────────────────────────────────────
-- Public: generateName(id, scope, originalName)
-- ────────────────────────────────────────────────
-- Luraph uses global-scope vars for the shortest names and
-- scoped vars for everything deeper. We mirror that here:
--   level 0 (nil / 0) → global counter style
--   level 1+           → scoped prefix+counter style

local function generateName(id, scope, originalName)
    local level = _scopeLevel(scope)
    local name

    if level <= 0 then
        -- Global / top-level: emit shortest possible counter names
        name = _buildGlobal()
    else
        -- Inner scope: emit base-prefixed counter names
        local key   = _scopeKey(scope)
        local entry = _getScope(key)
        name = _buildScoped(entry)
    end

    -- Absolute fallback (shouldn't happen but keeps obfuscator safe)
    if not name or RESERVED[name] then
        name = (originalName or "v") .. tostring(id) .. tostring(_lcg() % 9999)
    end

    _globalUsed[name] = true
    return name
end

-- ────────────────────────────────────────────────
-- Public: prepare(ast) — called once before renaming pass
-- ────────────────────────────────────────────────

local function prepare(ast)
    -- Re-seed LCG with time+clock for per-run entropy (same pattern as Rblx)
    local t = (os.time()  or 0) % 0x7FFFFFFF
    local c = math.floor((os.clock() * 1e6)) % 0x7FFFFFFF
    _seed   = (t * 1664525 + c * 6364136 + 1013904223) % 0x7FFFFFFF
    -- A few warm-up rounds so the first names aren't predictable
    for _ = 1, 8 do _lcg() end
    _resetState()
end

-- ────────────────────────────────────────────────

return {
    generateName = generateName,
    prepare      = prepare,
}
