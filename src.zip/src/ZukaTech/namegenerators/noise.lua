-- namegenerators/noise.lua
-- Noise — by Zuka
--
-- Names that look like corrupted memory or transmission static.
-- Mixes box-drawing characters, block elements, and geometric shapes —
-- all valid Lua 5.1 identifier bytes (>= 0x80).
--
-- Visually: █▓▒░▐▌  ╬╫╪╩╦  ▲◆■●▀
--
-- Why it's brutal:
--   - Looks like terminal corruption / a crashed process dump
--   - Three visually distinct "noise families" mixed together
--     so the output feels genuinely random and broken
--   - No two names look the same, but none look meaningful either
--   - Most renderers display these as filled rectangles — a solid wall of blocks

local util = require("ZukaTech.util")

-- Block elements (U+2580–U+259F) — filled rectangles, varying density
local BLOCKS = {
    "\xE2\x96\x80", -- ▀ upper half block
    "\xE2\x96\x81", -- ▁ lower one eighth
    "\xE2\x96\x82", -- ▂ lower one quarter
    "\xE2\x96\x83", -- ▃ lower three eighths
    "\xE2\x96\x84", -- ▄ lower half
    "\xE2\x96\x85", -- ▅ lower five eighths
    "\xE2\x96\x86", -- ▆ lower three quarters
    "\xE2\x96\x87", -- ▇ lower seven eighths
    "\xE2\x96\x88", -- █ full block
    "\xE2\x96\x89", -- ▉ left seven eighths
    "\xE2\x96\x8A", -- ▊ left three quarters
    "\xE2\x96\x8B", -- ▋ left five eighths
    "\xE2\x96\x8C", -- ▌ left half
    "\xE2\x96\x8D", -- ▍ left three eighths
    "\xE2\x96\x8E", -- ▎ left one quarter
    "\xE2\x96\x8F", -- ▏ left one eighth
    "\xE2\x96\x90", -- ▐ right half
    "\xE2\x96\x91", -- ░ light shade
    "\xE2\x96\x92", -- ▒ medium shade
    "\xE2\x96\x93", -- ▓ dark shade
    "\xE2\x96\x94", -- ▔ upper one eighth
    "\xE2\x96\x95", -- ▕ right one eighth
}

-- Box drawing (U+2500–U+257F) — lines, corners, intersections
local BOXDRAW = {
    "\xE2\x94\x80", -- ─ light horizontal
    "\xE2\x94\x82", -- │ light vertical
    "\xE2\x94\x8C", -- ┌ light down right
    "\xE2\x94\x90", -- ┐ light down left
    "\xE2\x94\x94", -- └ light up right
    "\xE2\x94\x98", -- ┘ light up left
    "\xE2\x94\xA4", -- ┤ light left vertical
    "\xE2\x94\xAC", -- ┬ light down horizontal
    "\xE2\x94\xB4", -- ┴ light up horizontal
    "\xE2\x94\xBC", -- ┼ light cross
    "\xE2\x95\x90", -- ═ double horizontal
    "\xE2\x95\x91", -- ║ double vertical
    "\xE2\x95\x94", -- ╔ double down right
    "\xE2\x95\x97", -- ╗ double down left
    "\xE2\x95\x9A", -- ╚ double up right
    "\xE2\x95\x9D", -- ╝ double up left
    "\xE2\x95\xA3", -- ╣ double left vertical
    "\xE2\x95\xA6", -- ╦ double down horizontal
    "\xE2\x95\xA9", -- ╩ double up horizontal
    "\xE2\x95\xAC", -- ╬ double cross
    "\xE2\x95\xAB", -- ╫ vertical double horizontal single
    "\xE2\x95\xAA", -- ╪ horizontal double vertical single
}

-- Geometric shapes (U+25A0–U+25FF) — squares, circles, triangles
local SHAPES = {
    "\xE2\x96\xA0", -- ■ black square
    "\xE2\x96\xA1", -- □ white square
    "\xE2\x96\xA2", -- ▢ white square with rounded corners
    "\xE2\x96\xAA", -- ▪ black small square
    "\xE2\x96\xAB", -- ▫ white small square
    "\xE2\x96\xB2", -- ▲ black up triangle
    "\xE2\x96\xB3", -- △ white up triangle
    "\xE2\x96\xB6", -- ▶ black right triangle
    "\xE2\x96\xB7", -- ▷ white right triangle
    "\xE2\x96\xBC", -- ▼ black down triangle
    "\xE2\x96\xBD", -- ▽ white down triangle
    "\xE2\x97\x80", -- ◀ black left triangle
    "\xE2\x97\x86", -- ◆ black diamond
    "\xE2\x97\x87", -- ◇ white diamond
    "\xE2\x97\x8F", -- ● black circle
    "\xE2\x97\x8B", -- ○ white circle
    "\xE2\x97\x8C", -- ◌ dotted circle
    "\xE2\x97\x8D", -- ◍ circle with vertical fill
    "\xE2\x97\x8E", -- ◎ bullseye
    "\xE2\x97\x9B", -- ◛ square with upper right diagonal half black
    "\xE2\x97\xA4", -- ◤ black upper left triangle
    "\xE2\x97\xA5", -- ◥ black upper right triangle
}

-- Combined pool with weights — blocks appear most (most visually dense)
local POOL   = {}
local POOL_W = { BLOCKS, BLOCKS, BLOCKS, BOXDRAW, BOXDRAW, SHAPES }

local MIN_LEN = 4
local MAX_LEN = 9
local order   = {}
local seed    = 0

local function prng(n)
    n = (n * 2654435761 + seed) % 0x100000000
    local result, bit, x, y = 0, 1, n, math.floor(n / 65536)
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then result = result + bit end
        x = math.floor(x / 2); y = math.floor(y / 2); bit = bit * 2
    end
    return result
end

local function generateName(id, scope)
    local len  = MIN_LEN + (prng(id) % (MAX_LEN - MIN_LEN + 1))
    local name = ""
    for i = 0, len - 1 do
        -- pick which family to draw from
        local family = POOL_W[(prng(id * 3 + i * 11) % #POOL_W) + 1]
        local idx    = (prng(id * 7 + i * 17) % #family) + 1
        name = name .. family[idx]
    end
    return "_" .. name
end

local function prepare(ast)
    seed  = math.random(0, 0xFFFFFF)
    -- shuffle each family independently for run variance
    util.shuffle(BLOCKS)
    util.shuffle(BOXDRAW)
    util.shuffle(SHAPES)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
