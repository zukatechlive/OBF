-- ZukaTech Obfuscator — namegenerators/zukazalgo.lua
-- ZukaZalgo — by Zuka, upgraded by ZukaTech
-- Fixed: combOrder bounds crash, weak prng avalanche, unpadded short names.
-- Upgraded: per-run mark density variation, double-layer combining, safe indexing.

local util = require("ZukaTech.util")

-- ────────────────────────────────────────────────
-- Combining Character Table
-- ────────────────────────────────────────────────

local COMBINING = {
    "\xCC\x80", "\xCC\x81", "\xCC\x82", "\xCC\x83", "\xCC\x84",
    "\xCC\x86", "\xCC\x87", "\xCC\x88", "\xCC\x8A", "\xCC\x8B",
    "\xCC\x8C", "\xCC\x8F", "\xCC\x91", "\xCC\x93", "\xCC\x94",
    "\xCC\x97", "\xCC\x98", "\xCC\x99", "\xCC\x9B", "\xCC\x9F",
    "\xCC\xA0", "\xCC\xA3", "\xCC\xA4", "\xCC\xA5", "\xCC\xA6",
    "\xCC\xA7", "\xCC\xA8", "\xCC\xAD", "\xCC\xAE", "\xCC\xB0",
    "\xCC\xB1", "\xCC\xB2", "\xCC\xB4", "\xCC\xB8", "\xCD\x85",
    "\xCD\x86", "\xCD\x8A", "\xCD\x8B", "\xCD\x8C", "\xCD\x91",
    "\xCD\x94", "\xCD\x95", "\xCD\x98", "\xCD\x9A", "\xCD\x9C",
    "\xCD\x9E", "\xCD\xA0", "\xCD\xA1", "\xCD\xA3", "\xCD\xA5",
    "\xCD\xA9", "\xCD\xAF",
}
local COMBINING_COUNT = #COMBINING  -- cached once, used everywhere

local DIRECTIONAL = {
    "\xE2\x80\x8F",  -- U+200F RIGHT-TO-LEFT MARK
    "\xD2\x89",      -- U+0489 COMBINING CYRILLIC MILLIONS SIGN
    "\xCC\xA9",      -- U+0329 COMBINING VERTICAL LINE BELOW
    "\xCD\x96",      -- U+0356 COMBINING RIGHT ARROWHEAD AND UP ARROWHEAD BELOW
}
local DIRECTIONAL_COUNT = #DIRECTIONAL

-- ────────────────────────────────────────────────
-- Charsets
-- ────────────────────────────────────────────────

local VarStartDigits = {}
local VarDigits      = {}

for c in ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"):gmatch(".") do
    table.insert(VarStartDigits, c)
end
for c in ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"):gmatch(".") do
    table.insert(VarDigits, c)
end

-- ────────────────────────────────────────────────
-- Per-run State
-- ────────────────────────────────────────────────

local seed      = 0
local combOrder = {}   -- shuffled index list into COMBINING
local minMarks  = 1    -- re-randomised each prepare()
local maxMarks  = 4
local MIN_LENGTH = 5   -- pad base name to at least this many chars

-- ────────────────────────────────────────────────
-- Pure Lua 5.1 Utilities
-- ────────────────────────────────────────────────

--- Bitwise XOR, pure Lua 5.1.
local function bxor(a, b)
    local result, bit = 0, 1
    while a > 0 or b > 0 do
        if a % 2 ~= b % 2 then result = result + bit end
        a   = math.floor(a / 2)
        b   = math.floor(b / 2)
        bit = bit * 2
    end
    return result
end

--- Stronger per-position hash — full avalanche via two mix rounds.
--- Replaces the original prng51 which had weak dispersion at low pos values.
---@param id  number
---@param pos number
---@return number  Value in [0, 0xFFFFFF]
local function hash(id, pos)
    -- Round 1: mix id and pos together with seed.
    local v = (id * 2654435761 + pos * 2246822519 + seed) % 0xFFFFFFFF
    -- Round 2: FNV-1a style finalisation for better avalanche.
    v = bxor(v, math.floor(v / 65536))
    v = (v * 0x01000193) % 0xFFFFFFFF
    v = bxor(v, math.floor(v / 256))
    return v
end

-- ────────────────────────────────────────────────
-- Core: Zalgo Character Builder
-- ────────────────────────────────────────────────

--- Stacks combining marks onto a single base character.
--- Fixed: combOrder is bounds-checked against COMBINING_COUNT, never #combOrder.
---@param ch  string  Single ASCII character.
---@param id  number
---@param pos number  Position index within the name (0-based).
---@return string
local function zalgoChar(ch, id, pos)
    local result = ch
    local range  = maxMarks - minMarks + 1
    local count  = minMarks + (hash(id * 17 + pos, pos) % range)

    for i = 1, count do
        -- FIX: index into combOrder, then clamp result to COMBINING_COUNT.
        -- Original bug: combOrder contained indices 1–#COMBINING but was
        -- accessed without bounding, allowing out-of-range lookups when
        -- combOrder was longer than COMBINING (possible after shuffle drift).
        local rawIdx = combOrder[(hash(id * 31 + pos * 7 + i, i) % #combOrder) + 1]
        local ci     = (rawIdx - 1) % COMBINING_COUNT + 1  -- safe clamp
        result       = result .. COMBINING[ci]
    end

    -- Directional chaos: ~20% chance per character, seeded deterministically.
    if hash(id + pos * 13, pos + 1) % 5 == 0 then
        local di = (hash(id * pos + 3, pos) % DIRECTIONAL_COUNT) + 1
        result   = result .. DIRECTIONAL[di]
    end

    return result
end

-- ────────────────────────────────────────────────
-- Core: Base Name Encoder
-- ────────────────────────────────────────────────

--- Encodes id to a base-N name using the shuffled charsets,
--- then pads to MIN_LENGTH before zalgo is applied.
---@param id number
---@return string, number  Raw char sequence and final encoded id for seeding.
local function buildBaseName(id)
    local chars = {}
    local pos   = 0

    local d = id % #VarStartDigits
    id      = math.floor((id - d) / #VarStartDigits)
    chars[1] = { ch = VarStartDigits[d + 1], pos = pos }
    pos = pos + 1

    while id > 0 do
        local dd = id % #VarDigits
        id       = math.floor((id - dd) / #VarDigits)
        pos      = pos + 1
        chars[pos] = { ch = VarDigits[dd + 1], pos = pos - 1 }
    end

    -- Pad to MIN_LENGTH with deterministic chars.
    local v = hash(id, 99)
    while #chars < MIN_LENGTH do
        v = (v * 1664525 + 1013904223) % 0xFFFFFFFF
        pos = pos + 1
        chars[#chars + 1] = { ch = VarDigits[(v % #VarDigits) + 1], pos = pos - 1 }
    end

    return chars
end

-- ────────────────────────────────────────────────
-- Public: generateName
-- ────────────────────────────────────────────────

local function generateName(id, scope)
    -- Safely extract numeric depth from scope (table or number or nil).
    local depth = 0
    if type(scope) == "number" then
        depth = scope
    elseif type(scope) == "table" then
        depth = tonumber(scope.depth or scope.level or scope.id or 0) or 0
    end

    -- Mix scope depth into id so same id at different scopes → different names.
    if depth > 0 then
        id = (id * 2654435761 + depth * 2246822519) % 0xFFFFFFFF
    end

    local chars  = buildBaseName(id)
    local result = {}

    for i, entry in ipairs(chars) do
        result[i] = zalgoChar(entry.ch, id, entry.pos)
    end

    return table.concat(result)
end

-- ────────────────────────────────────────────────
-- Public: prepare
-- ────────────────────────────────────────────────

local function prepare(ast)
    util.shuffle(VarDigits)
    util.shuffle(VarStartDigits)

    seed = math.random(0, 0xFFFFFF)

    -- Re-randomise mark density per run so outputs vary structurally.
    minMarks = math.random(1, 3)
    maxMarks = minMarks + math.random(2, 5)

    -- Rebuild and shuffle combOrder to exactly COMBINING_COUNT entries.
    -- FIX: original could end up with combOrder longer than COMBINING if
    -- util.shuffle inserted extra indices. Now always exactly 1..#COMBINING.
    combOrder = {}
    for i = 1, COMBINING_COUNT do combOrder[i] = i end
    util.shuffle(combOrder)
end

-- ────────────────────────────────────────────────

return {
    generateName = generateName,
    prepare      = prepare,
}