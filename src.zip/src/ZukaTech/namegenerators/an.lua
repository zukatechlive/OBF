-- ZukaTech Obfuscator — namegenerators/an.lua
--
-- AN (Alpha-Numeric) Name Generator
--
-- Produces names from a shuffled pool of a1–z100, giving 2600 unique
-- names before overflow.  Every compile gets a freshly shuffled pool so
-- the same source produces completely different name assignments each run.
--
-- Pool layout:
--   a1, a2 … a100,  b1 … b100,  c1 … c100,  …  z1 … z100
--   Total: 26 × 100 = 2600 names
--
-- Overflow (>2600 unique names):
--   Continues as  a101, a102 …  cycling through letters again,
--   guaranteeing uniqueness for arbitrarily large scripts.
--
-- Variants shipped in this file:
--   AN        — full a1-z100 pool, shuffled each run  (default)
--   ANLight   — same pool but only a1-z20 (520 names), lighter shuffle
--
-- Usage in CLI config:
--   NameGenerator = "AN"       -- full 2600-name pool
--   NameGenerator = "ANLight"  -- 520-name pool

local util = require("ZukaTech.util")

-- ─────────────────────────────────────────────────────────────
-- Shared helpers
-- ─────────────────────────────────────────────────────────────

local function shuffle(t)
    local n = #t
    for i = n, 2, -1 do
        local j = math.random(1, i)
        t[i], t[j] = t[j], t[i]
    end
end

-- Build a flat shuffled pool of  <letter><1..limit>  for all a-z.
-- Returns the pool table and a separate shuffled letter order so the
-- letter grouping itself is also randomised between runs.
local function buildPool(numLimit)
    -- Randomise which letter comes first in the pool each run
    local letters = {}
    for i = 0, 25 do
        letters[i + 1] = string.char(string.byte("a") + i)
    end
    shuffle(letters)

    local pool = {}
    for _, letter in ipairs(letters) do
        -- Also randomise the numeric range order within each letter group
        local nums = {}
        for n = 1, numLimit do nums[n] = n end
        shuffle(nums)

        for _, n in ipairs(nums) do
            pool[#pool + 1] = letter .. n
        end
    end
    return pool
end

-- ─────────────────────────────────────────────────────────────
-- AN  —  a1–z100  (2600-name pool)
-- ─────────────────────────────────────────────────────────────

local AN = (function()
    local pool       = {}
    local poolIdx    = 1
    local ovLetter   = 0   -- overflow letter index (0-25)
    local ovCounter  = 101 -- overflow counter

    local function generateName()
        if poolIdx <= #pool then
            local name = pool[poolIdx]
            poolIdx = poolIdx + 1
            return name
        else
            -- Overflow: cycle through letters continuing from 101+
            local letter = string.char(string.byte("a") + (ovLetter % 26))
            local name   = letter .. ovCounter
            ovLetter     = ovLetter + 1
            if ovLetter % 26 == 0 then
                ovCounter = ovCounter + 1
            end
            return name
        end
    end

    local function prepare()
        pool      = buildPool(100)
        poolIdx   = 1
        ovLetter  = 0
        ovCounter = 101
    end

    return { generateName = generateName, prepare = prepare }
end)()

-- ─────────────────────────────────────────────────────────────
-- ANLight  —  a1–z20  (520-name pool, lighter)
-- ─────────────────────────────────────────────────────────────

local ANLight = (function()
    local pool      = {}
    local poolIdx   = 1
    local ovLetter  = 0
    local ovCounter = 21

    local function generateName()
        if poolIdx <= #pool then
            local name = pool[poolIdx]
            poolIdx = poolIdx + 1
            return name
        else
            local letter = string.char(string.byte("a") + (ovLetter % 26))
            local name   = letter .. ovCounter
            ovLetter     = ovLetter + 1
            if ovLetter % 26 == 0 then
                ovCounter = ovCounter + 1
            end
            return name
        end
    end

    local function prepare()
        pool      = buildPool(20)
        poolIdx   = 1
        ovLetter  = 0
        ovCounter = 21
    end

    return { generateName = generateName, prepare = prepare }
end)()

-- ─────────────────────────────────────────────────────────────
-- Export both as separate generator tables.
-- namegenerators.lua registers each one individually.
-- ─────────────────────────────────────────────────────────────

return {
    AN      = AN,
    ANLight = ANLight,
}
