-- namegenerators/chaotic.lua
--
-- Generates short, visually noisy mixed-case names that mimic the
-- target obfuscator style: single letters, two-char combos, occasional
-- digit suffix, random case per character.
--
-- Examples: e, p, W, t, Go, Ro, fo, bo, p7, R7, c7, _o, xo, Ko

local util = require("ZukaTech.util")

-- Pool of base chars used by the target style.
-- Lowercase heavy with uppercase scattered in, plus underscore.
local BASE_CHARS = {
    "e","p","W","t","X","N","y","H","Q","l","M","d","z","h",
    "A","b","c","f","g","i","j","k","m","n","o","q","r","s",
    "u","v","w","x","G","R","V","Z","S","T","U","K","L","_",
    "B","C","D","E","F","I","J","O","P","Y",
}

-- Suffixes that appear on 2-char names (digit or letter)
local SUFFIXES = {
    "o","7","_","0","i","a","O","r","c","p","n","k",
    "","","","","","","",  -- weighted toward no suffix
}

-- Occasionally a name gets a trailing digit instead of letter
local DIGIT_SUFFIXES = { "7","0","_","4","3","6","9" }

local shuffledBase    = {}
local shuffledSuffix  = {}
local shuffledDigit   = {}

local function generateName(id)
    local bc = #shuffledBase   > 0 and shuffledBase   or BASE_CHARS
    local sc = #shuffledSuffix > 0 and shuffledSuffix or SUFFIXES
    local dc = #shuffledDigit  > 0 and shuffledDigit  or DIGIT_SUFFIXES

    -- Every ~20th name: single character only
    if id % 20 == 0 then
        return bc[(id % #bc) + 1]
    end

    -- Pick primary char
    local primary = bc[(id % #bc) + 1]

    -- Randomly flip case of primary
    local r = (id * 6271 + 1337) % 4
    if r == 0 then
        primary = primary:upper()
    elseif r == 1 then
        primary = primary:lower()
    end

    -- Pick suffix style based on id
    local stype = id % 5
    local suffix

    if stype == 0 then
        -- letter suffix (like "o", "i", "a", etc.)
        suffix = sc[((id * 31) % #sc) + 1]
    elseif stype == 1 then
        -- digit suffix (like "7", "0", "4")
        suffix = dc[((id * 17) % #dc) + 1]
    elseif stype == 2 then
        -- uppercase second char from base
        local s = bc[((id * 13 + 7) % #bc) + 1]:upper()
        suffix = s
    elseif stype == 3 then
        -- no suffix (short single-char style)
        suffix = ""
    else
        -- two-char from base pool, mixed case
        local s = bc[((id * 7 + 3) % #bc) + 1]
        local flip = (id * 11) % 3
        if flip == 0 then s = s:upper() end
        suffix = s
    end

    return primary .. suffix
end

local function prepare(ast)
    -- Deep copy and shuffle each table so every run differs
    for i = 1, #BASE_CHARS do shuffledBase[i]   = BASE_CHARS[i]   end
    for i = 1, #SUFFIXES    do shuffledSuffix[i] = SUFFIXES[i]     end
    for i = 1, #DIGIT_SUFFIXES do shuffledDigit[i] = DIGIT_SUFFIXES[i] end
    util.shuffle(shuffledBase)
    util.shuffle(shuffledSuffix)
    util.shuffle(shuffledDigit)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
